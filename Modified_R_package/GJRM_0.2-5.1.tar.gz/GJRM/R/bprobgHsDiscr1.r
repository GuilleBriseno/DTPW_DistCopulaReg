bprobgHsDiscr1 <- function(params, respvec, VC, ps, AT = FALSE){

 p1 <- p2 <- pdf1 <- pdf2 <- c.copula.be2 <- c.copula.be1 <- c.copula2.be1be2 <- NA

 
  # GBS: Construction of additive predictors 
   eta1 <- VC$X1%*%params[1:VC$X1.d2]
   
   # second margin (PWE)
   eta2 <- VC$X2%*%params[(VC$X1.d2+1):(VC$X1.d2+VC$X2.d2)]
   etad <- etas <- l.ln <- NULL 
 
   # copula parameter predictor:
 if(is.null(VC$X3))  teta.st <- etad <- params[(VC$X1.d2 + VC$X2.d2 + 1)]
 if(!is.null(VC$X3)) teta.st <- etad <- VC$X3%*%params[(VC$X1.d2+VC$X2.d2+1):(VC$X1.d2+VC$X2.d2+VC$X3.d2)]
 
   # small control of how large / small eta2 is 
   eta2 <- eta.tr(eta2, VC$margins[2])
     
   
   
   # GBS: This function has already been suitably modified
   # Compute pdf2, p2, and its respective gradients / hessians
  dHs <- distrHsDiscr(y2 = respvec$y2, eta2, 1, 1, nu = 1, nu.st = 1, margin2=VC$margins[2], naive = FALSE, 
                      y2m = VC$y2m, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr,
                      #
                      #
                      # GBS: I added these arguments for MBS models. 
                      #ListOfIDs = VC$ListOfIDs,
                      #PAMM_offset = VC$PAMM_offset,
                      # y2_iji = VC$y2_iji,
                      # iji_indices = VC$iji_indices,
                      # X2 = VC$X2, 
                      # X2_iji = VC$X2_iji,
                      # indices_zero = VC$indices_zeros
                      #
                      #
                      #
                      # GBS: I added these arguments for MBS models. 
                      MBS = VC$MBS, 
                      #
                      # MBS -> Double discrete-time survival or double PWE? (mixture is also possible)
                      MBS_TYPE = VC$MBS_TYPE,
                      #
                      # List of indices in the design matrix for a marginal distribution
                      ListOfIDs = VC$ListOfIDs,
                      #
                      # Offset used in piecewise-exponential (PWE) approach / marginal distribution
                      PAMM_offset = VC$PAMM_offset,
                      #
                      # the "original" censoring indicators
                      y2_iji = VC$y2_iji,
                      #
                      # indices of the location of the "original" censoring indicators
                      iji_indices = VC$iji_indices_y2,
                      #
                      # LONG design matrix
                      X2 = VC$X2, 
                      #
                      # entry in the LONG design matrix corresponding to the original entries.
                      X2_iji = VC$X2_iji,
                      #
                      #  indices of where the zeros are located in the LONG design matrix
                      indices_zero = VC$indices_zeros_y2,
                      #
                      # indices of the sequences corresponding to an ID that are of length ONE (only one interval survived)
                      length_one_sequences = VC$length_one_sequences_y2
                      )
   
   
  
  # GBS: THE THINGS EXTRACTED FROM dHs do not longer resemble standard objects created in vanilla GJRM 
  # The derivatives w.r.t. "eta" are already w.r.t. BETA, i.e. they are either vectors or matrices.
  
  # GBS: Scalars
   pdf2                         <- dHs$pdf2
   p2                           <- dHs$p2 
   
   # COLLECTION OF ROW-VECTORS!!
   derpdf2.dereta2              <- dHs$derpdf2.dereta2 
   derp2.dereta2                <- dHs$derp2.dereta2
   
   # LISTS OF MATRICES!!!
   der2p2.dereta2eta2           <- dHs$der2p2.dereta2eta2 
   der2pdf2.dereta2             <- dHs$der2pdf2.dereta2
   
   
   
   # GBS: mu2 is needed in case of MBS:
   if( VC$MBS ){
     
     # Simply extract mu2:
     mu2 <- dHs$mu2
     
     
   }
    
    
    pd1 <- probm(eta1, VC$margins[1], bc = TRUE, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr) 
    p1  <- 1 - pd1$pr                           #   pnorm(-eta1), p(y1=0)
  
  
  ########################################################################################################  
    
    # SMALL CONTROL FOR COPULA PARAMETER TETA
  resT    <- teta.tr(VC, teta.st)

teta.st1 <- teta.st2 <- teta.st <- resT$teta.st
teta1 <- teta2 <- teta <- resT$teta 
    
##################

Cop1 <- Cop2 <- VC$BivD 
nC1 <- nC2 <- VC$nC 


teta.ind1 <- as.logical(c(1,0,round(runif(VC$n-2))) ) 
teta.ind2 <- teta.ind1 == FALSE  


if(!(VC$BivD %in% VC$BivD2) && length(teta.st) > 1){

teta.st1 <- teta.st[teta.ind1]
teta.st2 <- teta.st[teta.ind2]

teta1 <- teta[teta.ind1]
teta2 <- teta[teta.ind2]

}

 
 
if(VC$BivD %in% VC$BivD2){

if(VC$BivD %in% VC$BivD2[c(1:4,13:16)])  teta.ind1 <- ifelse(VC$my.env$signind*teta > exp(VC$zerov), TRUE, FALSE)
if(VC$BivD %in% VC$BivD2[5:12]) teta.ind1 <- ifelse(VC$my.env$signind*teta > exp(VC$zerov) + 1, TRUE, FALSE) 
teta.ind2 <- teta.ind1 == FALSE 

VC$my.env$signind <- ifelse(teta.ind1 == TRUE,  1, -1) 

teta1 <-  teta[teta.ind1]
teta2 <- -teta[teta.ind2]

teta.st1 <- teta.st[teta.ind1]
teta.st2 <- teta.st[teta.ind2]

if(length(teta) == 1) teta.ind2 <- teta.ind1 <- rep(TRUE, VC$n)  

Cop1Cop2R <- Cop1Cop2(VC$BivD)
Cop1 <- Cop1Cop2R$Cop1
Cop2 <- Cop1Cop2R$Cop2

nC1 <- VC$ct[which(VC$ct[,1] == Cop1),2] 
nC2 <- VC$ct[which(VC$ct[,1] == Cop2),2]

} 
      
  
  ########################################################################################################
  
  
  C1 <- C2 <- A <- B <- NA
  

  # COMPUTE COPULA CDFs!!!
  # Various terms are involved here... 

  
if( length(teta1) != 0){  
  
  C1[teta.ind1] <- mm(BiCDF(p1[teta.ind1], p2[teta.ind1],          nC1, teta1, VC$dof), min.pr = VC$min.pr, max.pr = VC$max.pr  )
  C2[teta.ind1] <- mm(BiCDF(p1[teta.ind1], mm(p2[teta.ind1]-pdf2[teta.ind1], min.pr = VC$min.pr, max.pr = VC$max.pr), nC1, teta1, VC$dof), min.pr = VC$min.pr, max.pr = VC$max.pr  )
  
  A[teta.ind1] <- mm(C1[teta.ind1] - C2[teta.ind1], min.pr = VC$min.pr, max.pr = VC$max.pr)
  B[teta.ind1] <- mm( pdf2[teta.ind1] - A[teta.ind1], min.pr = VC$min.pr, max.pr = VC$max.pr)
  
}  


if( length(teta2) != 0){  
  
  C1[teta.ind2] <- mm(BiCDF(p1[teta.ind2], p2[teta.ind2],          nC2, teta2, VC$dof), min.pr = VC$min.pr, max.pr = VC$max.pr  )
  C2[teta.ind2] <- mm(BiCDF(p1[teta.ind2], mm(p2[teta.ind2]-pdf2[teta.ind2], min.pr = VC$min.pr, max.pr = VC$max.pr), nC2, teta2, VC$dof), min.pr = VC$min.pr, max.pr = VC$max.pr  )
  
  A[teta.ind2] <- mm(C1[teta.ind2] - C2[teta.ind2], min.pr = VC$min.pr, max.pr = VC$max.pr)
  B[teta.ind2] <- mm( pdf2[teta.ind2] - A[teta.ind2], min.pr = VC$min.pr, max.pr = VC$max.pr)
  
}

  
  # GBS: Computation of log-likelihood contributions
  l.par <- VC$weights*( respvec$cy*log( A ) + respvec$y1*log( B ) )
    
  ########################################################################################################
   
  c.copula.be1.C1 <- c.copula.be1.C2 <- c.copula.be2.C1 <- c.copula.be2.C2 <- c.copula.theta.C1 <- c.copula.theta.C2 <- NA
  
  
  # Computation of gradient / hessian terms of copula CDFs!!!
  
  if( length(teta1) != 0) dH1F <- copgHs(p1[teta.ind1], p2[teta.ind1], eta1=NULL, eta2=NULL, teta1, teta.st1, Cop1, VC$dof, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr)
  if( length(teta2) != 0) dH1S <- copgHs(p1[teta.ind2], p2[teta.ind2], eta1=NULL, eta2=NULL, teta2, teta.st2, Cop2, VC$dof, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr)
  
  if( length(teta1) != 0) dH2F <- copgHs(p1[teta.ind1], mm(p2[teta.ind1]-pdf2[teta.ind1], min.pr = VC$min.pr, max.pr = VC$max.pr), eta1=NULL, eta2=NULL, teta1, teta.st1, Cop1, VC$dof, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr) 
  if( length(teta2) != 0) dH2S <- copgHs(p1[teta.ind2], mm(p2[teta.ind2]-pdf2[teta.ind2], min.pr = VC$min.pr, max.pr = VC$max.pr), eta1=NULL, eta2=NULL, teta2, teta.st2, Cop2, VC$dof, min.dn = VC$min.dn, min.pr = VC$min.pr, max.pr = VC$max.pr) 
  
  
if( length(teta1) != 0){  
   
  c.copula.be1.C1[teta.ind1] <- dH1F$c.copula.be1 
  c.copula.be1.C2[teta.ind1] <- dH2F$c.copula.be1 
  
  c.copula.be2.C1[teta.ind1] <- dH1F$c.copula.be2 
  c.copula.be2.C2[teta.ind1] <- dH2F$c.copula.be2 
  
  c.copula.theta.C1[teta.ind1] <- dH1F$c.copula.theta # here there is theta star already
  c.copula.theta.C2[teta.ind1] <- dH2F$c.copula.theta
  
}  
  
  
  if( length(teta2) != 0){  
     
    c.copula.be1.C1[teta.ind2] <- dH1S$c.copula.be1 
    c.copula.be1.C2[teta.ind2] <- dH2S$c.copula.be1 
    
    c.copula.be2.C1[teta.ind2] <- dH1S$c.copula.be2 
    c.copula.be2.C2[teta.ind2] <- dH2S$c.copula.be2 
    
    c.copula.theta.C1[teta.ind2] <- dH1S$c.copula.theta # here there is theta star already
    c.copula.theta.C2[teta.ind2] <- dH2S$c.copula.theta
    
  }  
    
  
  # GBS: Beginning of construction of components for the gradient!
  # The stuff for margin 2 (pdf2, p2) requires extra care!
  if( VC$MBS ){
    
    
    # simple subtraction of matrices (each row is one gradient evaluation!)
    derp2m1.dereta2 <- derp2.dereta2 - derpdf2.dereta2
    
    # derivative of p1 w.r.t. eta1
    derp1.dereta1   <- pd1$derp1.dereta1    # -dnorm(-eta1) 
    
    
    ## Derivatives of the copula terms
    Cc <- c.copula.be1.C1 - c.copula.be1.C2 # mm(c.copula.be1.C1 - c.copula.be1.C2, min.pr = VC$min.pr, max.pr = VC$max.pr) 
    C  <- Cc*derp1.dereta1
    
    
    Cs    <- c.copula.theta.C1  - c.copula.theta.C2
    Cssb2 <- c.copula.be2.C1*derp2.dereta2 - c.copula.be2.C2*derp2m1.dereta2  
    
    
    
    # THE THREE GRADIENT ENTRIES!!!!!
    
    # GBS: First Derivative of log-lik w.r.t. eta1
    # scalar
    dl.dbe1      <- VC$weights*( ( respvec$cy/A - respvec$y1/B )*C  ) 
    
    # GBS: First Derivative of log-lik w.r.t. beta2!!! (this is A VECTOR)
    # already multiplied with the design matrix / vector!!!
    dl.dbe2      <- VC$weights*( respvec$cy/A*Cssb2 + respvec$y1/B*(derpdf2.dereta2 - Cssb2)    )
    
    # GBS: First Derivative of log-lik w.r.t. beta3 (copula parameter)
    # scalar
    dl.dteta.st  <- VC$weights*( ( respvec$cy/A - respvec$y1/B )*Cs   )                
    
    
    
  }else{  # VANILLA CASE (wont work after I'm done with this, probably)
  
  derp2m1.dereta2 <- derp2.dereta2 - derpdf2.dereta2
  derp1.dereta1   <- pd1$derp1.dereta1    # -dnorm(-eta1) 
  
  
  Cc <- c.copula.be1.C1 - c.copula.be1.C2 # mm(c.copula.be1.C1 - c.copula.be1.C2, min.pr = VC$min.pr, max.pr = VC$max.pr) 
  C  <- Cc*derp1.dereta1
  
  Cs    <- c.copula.theta.C1  - c.copula.theta.C2
  Cssb2 <- c.copula.be2.C1*derp2.dereta2 - c.copula.be2.C2*derp2m1.dereta2  
  
    dl.dbe1      <- VC$weights*( ( respvec$cy/A - respvec$y1/B )*C  ) 
    dl.dbe2      <- VC$weights*( respvec$cy/A*Cssb2 + respvec$y1/B*(derpdf2.dereta2 - Cssb2)    )
    dl.dteta.st  <- VC$weights*( ( respvec$cy/A - respvec$y1/B )*Cs   )                     
   
  }  
    
   
  ######################################################################################################## 
   
 c.copula2.be1.C1 <- c.copula2.be1.C2 <- c.copula2.be2.C1 <- c.copula2.be2.C2 <- c.copula2.be1be2.C1 <- c.copula2.be1be2.C2 <- c.copula2.be2th.C1 <- c.copula2.be2th.C2 <- c.copula2.theta.C1 <- c.copula2.theta.C2 <- c.copula.thet.C1 <- c.copula.thet.C2 <- derteta.derteta.st <- der2teta.derteta.stteta.st <- c.copula2.be1th.C1 <- c.copula2.be1th.C2 <- NA
   
   
   
if( length(teta1) != 0){     
   
    
    c.copula2.be1.C1[teta.ind1]           <- dH1F$c.copula2.be1
    c.copula2.be1.C2[teta.ind1]           <- dH2F$c.copula2.be1
    
    c.copula2.be2.C1[teta.ind1]           <- dH1F$c.copula2.be2
    c.copula2.be2.C2[teta.ind1]           <- dH2F$c.copula2.be2
    
    c.copula2.be1be2.C1[teta.ind1]        <- dH1F$c.copula2.be1be2
    c.copula2.be1be2.C2[teta.ind1]        <- dH2F$c.copula2.be1be2
    
    c.copula2.be2th.C1[teta.ind1]         <- dH1F$c.copula2.be2th
    c.copula2.be2th.C2[teta.ind1]         <- dH2F$c.copula2.be2th  
    
    c.copula2.theta.C1[teta.ind1]         <- dH1F$bit1.th2ATE 
    c.copula2.theta.C2[teta.ind1]         <- dH2F$bit1.th2ATE 
    
    c.copula.thet.C1[teta.ind1]           <- dH1F$c.copula.thet # NO star
    c.copula.thet.C2[teta.ind1]           <- dH2F$c.copula.thet    
   
    derteta.derteta.st[teta.ind1]         <- dH1F$derteta.derteta.st         # does not matter dH1 or dH2 
    der2teta.derteta.stteta.st[teta.ind1] <- dH1F$der2teta.derteta.stteta.st   
   
    c.copula2.be1th.C1[teta.ind1]         <- dH1F$c.copula2.be1th 
    c.copula2.be1th.C2[teta.ind1]         <- dH2F$c.copula2.be1th    
   
}   



if( length(teta2) != 0){     
   
    c.copula2.be1.C1[teta.ind2]           <- dH1S$c.copula2.be1
    c.copula2.be1.C2[teta.ind2]           <- dH2S$c.copula2.be1
    
    c.copula2.be2.C1[teta.ind2]           <- dH1S$c.copula2.be2
    c.copula2.be2.C2[teta.ind2]           <- dH2S$c.copula2.be2
    
    c.copula2.be1be2.C1[teta.ind2]        <- dH1S$c.copula2.be1be2
    c.copula2.be1be2.C2[teta.ind2]        <- dH2S$c.copula2.be1be2
    
    c.copula2.be2th.C1[teta.ind2]         <- dH1S$c.copula2.be2th
    c.copula2.be2th.C2[teta.ind2]         <- dH2S$c.copula2.be2th  
    
    c.copula2.theta.C1[teta.ind2]         <- dH1S$bit1.th2ATE 
    c.copula2.theta.C2[teta.ind2]         <- dH2S$bit1.th2ATE 
    
    c.copula.thet.C1[teta.ind2]           <- dH1S$c.copula.thet # NO star
    c.copula.thet.C2[teta.ind2]           <- dH2S$c.copula.thet    
   
    derteta.derteta.st[teta.ind2]         <- dH1S$derteta.derteta.st         # does not matter dH1 or dH2 
    der2teta.derteta.stteta.st[teta.ind2] <- dH1S$der2teta.derteta.stteta.st   
   
    c.copula2.be1th.C1[teta.ind2]         <- dH1S$c.copula2.be1th 
    c.copula2.be1th.C2[teta.ind2]         <- dH2S$c.copula2.be1th    
   
}   


  # GBS: Computation / construction of the hessian block entries
  # scalar (binary margin)
  der2p1.dereta1eta1 <- pd1$der2p1.dereta1eta1
  
  # scalar (binary margin)
  derC.dereta1 <- (c.copula2.be1.C1 - c.copula2.be1.C2)*derp1.dereta1^2 + Cc*der2p1.dereta1eta1
  
  # scalar (binary margin)
  derCs.dertheta.st <- (c.copula2.theta.C1 - c.copula2.theta.C2)*derteta.derteta.st^2 + (c.copula.thet.C1 - c.copula.thet.C2)*der2teta.derteta.stteta.st
  
  # already vectors
  derA.dereta2 <- c.copula.be2.C1*derp2.dereta2   - c.copula.be2.C2*derp2m1.dereta2 
  derB.dereta2 <- derpdf2.dereta2 - derA.dereta2  
  
  # subtraction carried out over each element of a list of matrices!
  # der2p2m1.dereta2eta2 <- der2p2.dereta2eta2 - der2pdf2.dereta2
  # returns a list of matrices of length n
  der2p2m1.dereta2eta2 <- lapply(1:length(VC$ListOfIDs), function(i) der2p2.dereta2eta2[[i]] - der2pdf2.dereta2[[i]] )
  
  
  # this now involves subtraction using a list of matrices!
  #derCssb2.dereta2 <- c.copula2.be2.C1*derp2.dereta2^2 + c.copula.be2.C1*der2p2.dereta2eta2 - (c.copula2.be2.C2*derp2m1.dereta2^2 + c.copula.be2.C2*der2p2m1.dereta2eta2)                                                                     
  derCssb2.dereta2 <- lapply(1:length(VC$ListOfIDs), function(i)
                      #
                      c.copula2.be2.C1[i] * tcrossprod(derp2.dereta2[i,], derp2.dereta2[i,]) + c.copula.be2.C1[i] * der2p2.dereta2eta2[[i]] -
                      #
                      ( c.copula2.be2.C2[i] * tcrossprod(derp2m1.dereta2[i,], derp2m1.dereta2[i,])  +  c.copula.be2.C2[i] * der2p2m1.dereta2eta2[[i]] )  
                      )
  
                      
  # this is a collection of row-vectors because it is already a derivative w.r.t. beta_2 (PWE) and then w.r.t. eta_1!!!
  derC.dereta2 <- (c.copula2.be1be2.C1*derp2.dereta2 - c.copula2.be1be2.C2*derp2m1.dereta2)*as.numeric(derp1.dereta1)    
  
  
  # Cross-derivative of C and the w.r.t. beta_3 (scalar, since both parts were already scalars!)
  derC.dertheta.st <- (c.copula2.be1th.C1 - c.copula2.be1th.C2)*derp1.dereta1 
  
  # Cross-redivative of Cs and then w.r.t. beta_2 (PWE) (collection of row vector, beacuse this was already a collection of vectors due to beta_2 (PWE))
  derCs.dereta2      <- c.copula2.be2th.C1*derp2.dereta2 - c.copula2.be2th.C2*derp2m1.dereta2
  
  
  # BLOCK ENTRIES FOR THE HESSIAN 
  # these two entries are 
  # scalar
  d2l.be1.be1      <- -VC$weights*( (-respvec$cy/A^2 - respvec$y1/B^2)*C^2 + ( respvec$cy/A - respvec$y1/B )*derC.dereta1 )
  
  # scalar 
  d2l.rho.rho      <- -VC$weights*( (-respvec$cy/A^2 - respvec$y1/B^2)*Cs^2 + ( respvec$cy/A - respvec$y1/B )*derCs.dertheta.st )
  
  # this right here is a simple operation between scalars and a list of matrices
  # MATRIX
  #d2l.be2.be2      <- -VC$weights*( -respvec$cy*derA.dereta2*Cssb2/A^2 + respvec$cy*derCssb2.dereta2/A - respvec$y1*derB.dereta2/B^2*(derpdf2.dereta2-Cssb2) + respvec$y1/B*( der2pdf2.dereta2 - derCssb2.dereta2)  )
  
  # This is broken into two steps: one is the combination of operations between scalars, row-vectors and matrices
  # second step is the multiplication of the weights
  d2l.be2.be2      <- lapply(1:length(VC$ListOfIDs), function(i)  
    #
                      -respvec$cy[i] * tcrossprod(Cssb2[i,], derA.dereta2[i,]) / A[i]^2  + 
                       respvec$cy[i] * derCssb2.dereta2[[i]] / A[i] - 
                       respvec$y1[i] * tcrossprod(derB.dereta2[i,], ( derpdf2.dereta2 - Cssb2 )[i,] ) / B[i]^2  + 
                       respvec$y1[i] * ( der2pdf2.dereta2[[i]]  - derCssb2.dereta2[[i]] ) / B[i]
  #
    )
    
    
  d2l.be2.be2      <- lapply(1:length(VC$ListOfIDs), function(i) 
                            -VC$weights[i] * ( d2l.be2.be2[[i]] ) 
                            )
  
  
  # collection of vectors
  d2l.be1.be2      <- -VC$weights*( (-respvec$cy*derA.dereta2/A^2 + respvec$y1*derB.dereta2/B^2)*as.numeric(C) + (respvec$cy/A - respvec$y1/B)*derC.dereta2 )
  
  # scalar
  d2l.be1.rho      <- -VC$weights*( (-respvec$cy/A^2 - respvec$y1/B^2)*C*Cs + ( respvec$cy/A - respvec$y1/B )*derC.dertheta.st )
  
  # I added the FULL ADDITIVE MODEL COPULA PARAMETER CASE HERE
  # (is created later because of the structure of the function)
  # collection of vectors
  #d2l.be2.rho      <- -VC$weights*( (-respvec$cy*derA.dereta2/A^2 + respvec$y1*derB.dereta2/B^2)*Cs + ( respvec$cy/A - respvec$y1/B )*derCs.dereta2 )
  d2l.be2.rho      <- -VC$weights*( (-respvec$cy*derA.dereta2/A^2 + respvec$y1*derB.dereta2/B^2)*Cs + ( respvec$cy/A - respvec$y1/B )*derCs.dereta2 )
  
  
  
# GBS: FINAL CONSTRUCTION OF THE HESSIAN! Here the block matrices are allocated to 
    # their respective entry of the Hessian.
# GBS: Added MBS cases here:
if( VC$MBS ){
  
  
  # GBS: CASE OF INTERCEPT ONLY IN THE COPULA PARAMETER
  if( is.null(VC$X3) ){
    
    
    # GBS: These two below are fine!
    be1.be1 <- crossprod(VC$X1*c(d2l.be1.be1),VC$X1)
    be1.rho <- t(t(rowSums(t(VC$X1*c(d2l.be1.rho)))))
    
    # Main diagonal element:
    #be2.be2 <- crossprod(VC$X2*c(d2l.be2.be2),VC$X2)
    be2.be2 <- Reduce("+", d2l.be2.be2)
    
    # Off-diagonal elements:
    #be1.be2 <- crossprod(VC$X1*c(d2l.be1.be2),VC$X2)
    #be2.rho <- t(t(rowSums(t(VC$X2*c(d2l.be2.rho)))))
    #be1.be2 <- Reduce("+", d2l.be1.be2)
    #be2.rho <- Reduce("+", d2l.be2.rho)
    be1.be2 <- crossprod(VC$X1, d2l.be1.be2)
    be2.rho <- t(t(rowSums(t(d2l.be2.rho))))
    
    
    # GBS: HESSIAN
    H <- rbind( cbind( be1.be1    , be1.be2    , be1.rho ), 
                cbind( t(be1.be2) , be2.be2    , be2.rho ), 
                cbind( t(be1.rho) , t(be2.rho) , sum(d2l.rho.rho) ) 
    ) 
    
    
    # GBS: GRADIENT
                # GBS: Vector of partial derivatives of log-lik w.r.t. beta1
    G   <- -c( colSums( c(dl.dbe1)*VC$X1 ) ,
               #
               # GBS: Vector of partial derivatives of log-lik w.r.t. beta2
               colSums( dl.dbe2 ) ,
               #
               #
               # GBS: Vector of partial derivatives of log-lil w.r.t. beta3
               sum( dl.dteta.st ) )
    
  }
  
  
  # GBS: CASE OF FULL ADDITIVE MODEL FOR COPULA PARAMETER
  if( !is.null(VC$X3) ){
    
    
    # New construction of hessian:
    # Diagonal entries:
    be1.be1 <- crossprod(VC$X1*c(d2l.be1.be1),VC$X1)
    rho.rho <- crossprod(VC$X3*c(d2l.rho.rho),VC$X3)
    
    # PWE diagonal entry:
    #be2.be2 <- crossprod(VC$X2*c(d2l.be2.be2),VC$X2)
    be2.be2 <- Reduce("+", d2l.be2.be2)
    
    # Off-diagonal entry beta1 / beta3
    be1.rho <- crossprod(VC$X1*c(d2l.be1.rho),VC$X3)
    
    # Off-diagonal entries with PWE:
    be1.be2 <- crossprod(VC$X1, d2l.be1.be2)
    be2.rho <- crossprod(d2l.be2.rho, VC$X3)
    
    
    
    
    
    # GBS: HESSIAN
    H <- rbind( cbind( be1.be1    , be1.be2    , be1.rho ), 
                cbind( t(be1.be2) , be2.be2    , be2.rho ), 
                cbind( t(be1.rho) , t(be2.rho) , rho.rho ) 
    ) 
    
    
    
    # GBS: GRADIENT
    G   <- -c( colSums(      c(dl.dbe1)*VC$X1 ) ,
               #
               # GBS: Vector of partial derivatives of log-lik w.r.t. beta2
               colSums(      dl.dbe2 ) ,
               #
               #
               colSums(      c(dl.dteta.st)*VC$X3 ) ) 
    
  }
  
  
  
}else{   
    
if( is.null(VC$X3) ){

  be1.be1 <- crossprod(VC$X1*c(d2l.be1.be1),VC$X1)
  be2.be2 <- crossprod(VC$X2*c(d2l.be2.be2),VC$X2)
  be1.be2 <- crossprod(VC$X1*c(d2l.be1.be2),VC$X2)
  be1.rho <- t(t(rowSums(t(VC$X1*c(d2l.be1.rho)))))
  be2.rho <- t(t(rowSums(t(VC$X2*c(d2l.be2.rho)))))
  
  H <- rbind( cbind( be1.be1    , be1.be2    , be1.rho ), 
              cbind( t(be1.be2) , be2.be2    , be2.rho ), 
              cbind( t(be1.rho) , t(be2.rho) , sum(d2l.rho.rho) ) 
            ) 
            
           
         
  G   <- -c( colSums( c(dl.dbe1)*VC$X1 ) ,
             colSums( c(dl.dbe2)*VC$X2 ) ,
             sum( dl.dteta.st ) )
    
}


if( !is.null(VC$X3) ){





  be1.be1 <- crossprod(VC$X1*c(d2l.be1.be1),VC$X1)
  be2.be2 <- crossprod(VC$X2*c(d2l.be2.be2),VC$X2)
  be1.be2 <- crossprod(VC$X1*c(d2l.be1.be2),VC$X2)
  be1.rho <- crossprod(VC$X1*c(d2l.be1.rho),VC$X3)
  be2.rho <- crossprod(VC$X2*c(d2l.be2.rho),VC$X3)
  rho.rho <- crossprod(VC$X3*c(d2l.rho.rho),VC$X3)
  
  H <- rbind( cbind( be1.be1    , be1.be2    , be1.rho ), 
              cbind( t(be1.be2) , be2.be2    , be2.rho ), 
              cbind( t(be1.rho) , t(be2.rho) , rho.rho ) 
            ) 
            
           
  G   <- -c( colSums(      c(dl.dbe1)*VC$X1 ) ,
             colSums(      c(dl.dbe2)*VC$X2 ) ,
             colSums(  c(dl.dteta.st)*VC$X3 ) ) 
    
}

}
    
    
    
         # GBS: Sum of individual log-likelihood contributions
         res <- -sum(l.par)

if(VC$extra.regI == "pC" && VC$hess==FALSE) H <- regH(H, type = 1)
  
  S.h  <- ps$S.h
  
  if( length(S.h) != 1){
  
  S.h1 <- 0.5*crossprod(params,S.h)%*%params
  S.h2 <- S.h%*%params
  
  } else S.h <- S.h1 <- S.h2 <- 0   
  
  S.res <- res
  res   <- S.res + S.h1
  G     <- G + S.h2
  H     <- H + S.h 
        
if(VC$extra.regI == "sED") H <- regH(H, type = 2) 
  
  



         list(value=res, gradient=G, hessian=H, S.h=S.h, S.h1=S.h1, S.h2=S.h2, l=S.res, l.par=l.par, ps = ps, etas = etas,
              eta1=eta1, eta2=eta2, etad=etad,
              dl.dbe1=dl.dbe1, dl.dbe2=dl.dbe2, dl.dteta.st = dl.dteta.st,
              BivD=VC$BivD,                             p1 = 1-p1, p2 = p2, pdf1 = pdf1, pdf2 = pdf2,          
	      	                    c.copula.be2 = c.copula.be2,
	      	                    c.copula.be1 = c.copula.be1,
              c.copula2.be1be2 = c.copula2.be1be2, theta.star = teta.st,
              teta.ind2 = teta.ind2, teta.ind1 = teta.ind1,
              Cop1 = Cop1, Cop2 = Cop2, teta1 = teta1, teta2 = teta2)      

}




     























