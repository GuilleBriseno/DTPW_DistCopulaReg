distrHsDiscr <- function(y2, eta2, sigma2, sigma2.st, nu, nu.st, margin2, naive = FALSE, y2m,
                         min.dn, min.pr, max.pr, 
                         #
                         #
                         # Mixed binary survival model
                         MBS = NULL, 
                         # Classic discrete or using discrete representations:
                         #
                         BivDiscSurvClassic = FALSE,
                         # PWE or DT
                         MBS_TYPE = NULL,
                         # List of indices in the design matrix for a marginal distribution
                         ListOfIDs = NULL,
                         # Offset used in piecewise-exponential (PWE) approach / marginal distribution
                         PAMM_offset = NULL,
                         # the "original" censoring indicators
                         y2_iji = NULL,
                         # indices of the location of the "original" censoring indicators
                         iji_indices = NULL,
                         # LONG design matrix
                         X2 = NULL, 
                         # entry in the LONG design matrix corresponding to the original entries.
                         X2_iji = NULL, 
                         #  indices of where the zeros are located in the LONG design matrix
                         indices_zeros = NULL, 
                         # indices of the sequences corresponding to an ID that are of length ONE (only one interval survived)
                         length_one_sequences = NULL){

  
  
  # GBS: I took over this function, I hope my sins will be forgotten or forgiven

p2 <- derp2.dersigma.st <- derp2.dereta2 <- der2p2.dereta2eta2 <- der2p2.dersigma2.st2 <- der2p2.dereta2dersigma2.st <- indx <- 1

sigma <- sigma2


der2pdf2.dereta2dernu.st    = 1
der2pdf2.sigma2.st2dernu.st = 1
derpdf2.dernu.st            = 1
der2pdf2.dernu.st2          = 1
derp2.nu.st                 = 1
der2p2.dernu.st2            = 1
der2p2.dereta2dernu.st      = 1
der2p2.dersigma2.stdernu.st = 1

cont1par <- c("PO","ZTP","DGP0")
cont2par <- c("NBI","NBII","NBIa","NBIIa","PIG","PO","ZTP","DGP","DGPII","DGP0")
cont3par <- c("DEL","SICHEL")

# library(Deriv); library(numDeriv)
# expr <- expression(  )
# Simplify( D(D(expr, "mu2"),"sigma2") )
# func0 <- function(mu2){   }
# grad(func0 , mu2)
#func <- function(x) pNBI(y2, mu = x[1], sigma = sqrt(x[2])) 
#hessian(func, c(mu2,sigma2))
############################################################################
# remember that eta2 will have to disappear if we change default link on mu2
# this only applies to cases in which mu2 must be positive
# otherwise things are fine
############################################################################

#######################################################################
# Define generic numerical derivative functions
#######################################################################



if(margin2 %in% c("PIG","NBI","NBII","NBIa","NBIIa")){

derpdf2.dermu2FUNC2p <- function(func, y2, mu2, sigma) numgh(func, mu2)
derpdf2.sigma2FUNC2p <- function(func, y2, mu2, sigma) numgh(func, sigma)  

der2pdf2.mu2dersigma2FUNC2p <- function(func, y2, mu2, sigma) numch(func, mu2, sigma)

}



#######################################################################

# GBS: Here I added a check for MBS. In here either PWE parts (Pseudo-poisson) or Discrete-time survival (bernoulli) parts will be computed!
if(margin2 == "PO"){

  
  if( MBS ){
   
    
    
    #  Survival curve approach: 
    if( BivDiscSurvClassic ){
      
      
      # CLOG-LOG LINK
      # mu2 ----> exp( eta2 )
      mu2 <- exp(eta2) 
      
      # GBS: I had to move ifef up to here! 
      mu2 <- ifef(mu2)
      
      # compute / update the mu2_iji (i.e. last of the sequence of length j(i) per individual)
      mu2_iji <- mu2[iji_indices]
      
      # derivatives w.r.t. eta2 are just passed through. These won't be used ANYWAY. 
      dermu2.dereta2 <- mu2
      der2mu2.dereta2eta2 <- mu2
      
      # no sigma parameter in these models
      dersigma2.dersigma2.st  <- 0  
      dersigma2.dersigma2.st2 <- 0
      
      
      # GBS: This check is not necessary but I'll leave it here
      if(max(y2) > 170){
        
        prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
        mu2 <- mpfr(mu2, prec)
        y2  <- mpfr( y2, prec)   
        
        
      }        
      
      ###########################################################################
      ###########################################################################
      # Some helper functions!
      
      # The definition of these is the following: 
      # exp(-sum_j mu2_ij ) ---> scalar (sum up to the j(i)-1 entry!)
      Term1 <- function(mu2_ij){
        
        # always sum-up this scalar up to the second to last entry!
        t1 <- exp( - sum( mu2_ij[ -length(mu2_ij) ] ) )
        
        # Output is a SCALAR
        return(t1)
      }
      
      # this function produces a list of matrices!
      # sum_j up to j(i)-1!!!! ( mu2_ij x_ij x_ij^T ) ----> sum of j(i)-1 matrices
      Term2 <- function(mu2_ij, cov_vec){
        
        
        # sequence of only ONE interval
        if(is.null(dim(cov_vec))){
          
          # this one works for sequences of length 1! term2.5 is NOT NEEDED in those cases
          t2 <- mu2_ij * tcrossprod( as.vector(cov_vec), 
                                     as.vector(cov_vec) )
          
        }else{
          
          
          # should be a sum of j(i)-1 matrices 
          t2 <- Reduce("+",
                       lapply(1:(nrow(cov_vec)-1),
                              function(i) 
                                mu2_ij[i] * tcrossprod( cov_vec[i,], 
                                                        cov_vec[i,]) 
                       ))
          
          
        }
        
        return(t2)
        
      }
      
      # ( mu2_ij x_ij x_ij^T )  ----> the missing matrix of the j(i)-th interval
      Term2.5 <- function(mu2_iji, cov_vec_iji){
        
        # this only uses THE LAST vector! 
        term2.5 <- mu2_iji * tcrossprod(as.vector(cov_vec_iji), 
                                        as.vector(cov_vec_iji))
        
        return(term2.5)
        
      }
      
      # sum_j ( mu2_ij x_ij ) ---> vector
      Term3 <- function(mu2_ij, cov_vec){
        
        
        # check of length
        if(is.null(dim(cov_vec))){
          
          # for sequences of length 1 it doesn't matter.
          t3 <- mu2_ij * cov_vec
          
        }else{
          
          last_entry <- nrow(cov_vec)
          
          # if the sequence has TWO entries, colsums won't work....
          # special case for sequences of length TWO:
          if(nrow(cov_vec) == 2){
            
            t3 <-  c(mu2_ij[ -last_entry ]) * cov_vec[ -last_entry, ] 
            
          }else{
            
            # sum up to the SECOND TO LAST ENTRY (j(i)-1)!
            t3 <- colSums( c(mu2_ij[ -last_entry ]) * cov_vec[ -last_entry, ] )
            
          }
          
        }
        
        # output is a VECTOR
        return(t3)
      }
      
      ###########################################################################
      ###########################################################################
      
      # GBS: compute these little quantities:
      # this is a scalar!
      terms1 <- c(sapply(ListOfIDs, 
                         function(i) 
                           Term1(mu2[i]))
      )
      
      # This is a (list of) matrix!
      terms2 <- lapply(ListOfIDs, 
                       function(i) 
                         Term2(mu2[i], 
                               X2[i,])
      )
      
      # This is a list of matrices that only includes the j(i)-term!
      terms2.5 <- lapply(1:length(ListOfIDs),
                         function(i)
                           Term2.5(mu2_iji[i], X2_iji[i,]))
      
      # This is a vector!
      terms3 <- t(sapply(ListOfIDs, 
                         function(i) 
                           Term3(mu2[i], 
                                 X2[i,]))
      )
      
      # GBS: Carry out the ifef() checks of the terms in HERE! (might not be needed.....)
      terms1 <- ifef(terms1)
      
      
      
      # All of the terms above are summed up to the second-to-last-entry!
      ###########################################################################
      ###########################################################################
      ###########################################################################
      # GBS: 
      #
      # function for S(t-1)
      pdf_FUNC <-  function(mu2, term1, length_one_sequences, iji_indices){
        
        pdf <- numeric(length(iji_indices))
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          # all terms of the PDF are created like this:
          pdf <- term1 
          
        }else{
          
          # Sequences of length 1
          pdf[length_one_sequences] <- 1
          
          # Sequences of length larger than 1
          pdf[-length_one_sequences] <- term1[-length_one_sequences] 
          
          
          
        }
        
        
        return(pdf)
        
      }
      
      # function for S(t)
      cdf_FUNC <-  function(mu2, mu2_iji, term1, length_one_sequences, iji_indices){
        
        cdf <- numeric(length(iji_indices))
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          # all terms of the PDF are created like this:
          cdf <- term1 * exp( - mu2[iji_indices] )
          
        }else{
          
          # Sequences of length 1
          cdf[length_one_sequences] <- exp( - exp( mu2[length_one_sequences] ) )
          
          # Sequences of length larger than 1
          cdf[-length_one_sequences] <- term1[-length_one_sequences] * exp( - mu2_iji[-length_one_sequences] )
          
          
        }
        
        
        return(cdf)
      }
      
      ###########################################################################
      ###########################################################################
      ###########################################################################
      # Compute S(t-1):
      pdf2 <- pdf_FUNC(mu2, terms1, length_one_sequences, iji_indices)
      
      
      # GBS: derivatives of discrete-time survival function 
      derpdf2.derbeta_FUNC <- function(term1, term3, length_one_sequences){
        
        der_pdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
        sample_IDs <- 1:nrow(term3)
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          der_pdf <- - term1 * term3
          
          # There are sequences of length 1 and others with length > 1.  
        }else{
          
          # Sequences of length 1
          der_pdf[length_one_sequences, ] <- rep(0, ncol(term3))
          
          # Sequences of length larger than 1
          der_pdf[-length_one_sequences,] <-  t(sapply(sample_IDs[-length_one_sequences], function(i)
            
            #  - term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,])
            - term1[i] * term3[i,] 
          )
          )
        }
        
        return(der_pdf)
      }
      
      # this calculates already A VECTOR:
      # Should be of length i = 1,...,n. (i.e. the nrow should be n)
      derpdf2.derbeta2     <- derpdf2.derbeta_FUNC(terms1, terms3, length_one_sequences)
      
      
      # GBS: I will just calculate the hessian of PDF here...
      der2pdf2.derbetbet2_FUNC <- function(term1, term2, term2.5, term3, mu2_iji, x2_iji, length_one_sequences){
        
        d2pdf2 <- vector(mode = "list", length = nrow(term3))
        
        sample_IDs <- 1:nrow(term3)
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          d2pdf2 <- sapply(1:length(mu2_iji), 
                           function(i)
                             
                             term1[i] * tcrossprod( term3[i,] , term3[i,] ) - term1[i] * term2[[i]],
                           
                           simplify = FALSE
          )
          
          # There are sequences of length 1 and others with length > 1.  
        }else{
          
          # Sequences of length 1
          d2pdf2[length_one_sequences] <- sapply(length_one_sequences, 
                                                 function(i)
                                                   
                                                   matrix(0, ncol = ncol(term3), nrow = ncol(term3)),
                                                 
                                                 simplify = FALSE
          )
          
          
          
          
          # Sequences of length larger than 1
          d2pdf2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], function(i)
            
            term1[i] * tcrossprod( term3[i,] , term3[i,] ) - term1[i] * term2[[i]], 
            
            simplify = FALSE
          )
          
          
          
          
        }
        
        
        return(d2pdf2)
      }
      
      
      der2pdf2.dermu2       <- der2pdf2.derbetbet2_FUNC(terms1, terms2, terms2.5, terms3, mu2_iji, X2_iji, length_one_sequences)
      
      
      # no sigma parameter in these approaches
      derpdf2.sigma2        <- 0
      der2pdf2.dersigma22   <- 0
      der2pdf2.mu2dersigma2 <- 0
      
      
      
      if(naive == FALSE){   # needs y2m 
        
        # GBS: The CDF changes here too! 
        # This function needs a list of indices as well
        p2 <- cdf_FUNC(mu2, mu2_iji, terms1, length_one_sequences, iji_indices)
        
        
        ##  GRADIENT of S(t):
        derp2.derbe_FUNC <- function(term1, term3, mu2_iji, x2_iji, length_one_sequences){
          
          der_cdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
          sample_IDs <- 1:nrow(term3)
          
          # there are NO SEQUENCES OF LENGTH 1
          if(length(length_one_sequences) == 0){
            
            der_pdf <- - term1 * exp( - mu2_iji ) * (term3 + mu2_iji * x2_iji)
            
            # There are sequences of length 1 and others with length > 1.  
          }else{
            
            # sequences of length 1
            der_cdf[length_one_sequences, ] <- t(sapply(length_one_sequences, 
                                                        function(i)
                                                          
                                                          - exp( - mu2_iji[i] ) * mu2_iji[i] * x2_iji[i,]
                                                        
            )
            )
            
            # Sequences of length larger than 1
            der_cdf[-length_one_sequences,] <- t(sapply(sample_IDs[-length_one_sequences], 
                                                        function(i) 
                                                          
                                                          - term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,])
                                                        
            )
            )
            
          }
          
          return(der_cdf)
          
        }
        
        
        derp2.dermu2           <- derp2.derbe_FUNC(terms1, terms3, mu2_iji, X2_iji, length_one_sequences)
        
        
        # HESSIAN of CDF:
        # GBS: Derivatives for the PWE margin CDF w.r.t. the coeff vector and then the coeff vector TRANSPOSED
        der2p2.derbebeT_FUNC       <- function(term1, term2, term2.5, term3, y2_iji, mu2_iji, x2_iji, length_one_sequences){
          
          
          d2p2 <- vector(mode = "list", length = nrow(term3))
          
          sample_IDs <- 1:nrow(term3)
          
          # there are NO SEQUENCES OF LENGTH 1
          if(length(length_one_sequences) == 0){
            
            d2p2 <- sapply(1:length(y2_iji), 
                           function(i)
                             term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , 
                                                                          (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) 
                           - term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] ),
                           simplify = FALSE
            )
            
            # There are sequences of length 1 and others with length > 1.  
          }else{
            
            # Sequences of length 1
            d2p2[length_one_sequences ] <- sapply(length_one_sequences, 
                                                  function(i)
                                                    
                                                    exp(- mu2_iji[i] ) * (mu2_iji[i])^2 * tcrossprod( x2_iji[i,], x2_iji[i,] ) 
                                                  - 
                                                    exp( - mu2_iji[i]) * mu2_iji[i] * tcrossprod(x2_iji[i,], x2_iji[i,] )
                                                  ,
                                                  simplify = FALSE
            )
            
            
            
            
            # Sequences of length larger than 1
            d2p2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], 
                                                  function(i)
                                                    
                                                    term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) 
                                                  - 
                                                    term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] ), 
                                                  simplify = FALSE
            )
            
            
            
            
          }
          
          return(d2p2)
          
        }
        
        
        # This derivative i s already the FULL VECTOR!
        der2p2.dermu22           <- der2p2.derbebeT_FUNC(terms1, terms2, terms2.5, terms3, y2_iji, mu2_iji, X2_iji, length_one_sequences)
        
        # Some stuff w.r.t. sigma that is not necessary for us.
        derp2.dersigma2        <- 0
        der2p2.dersigma22      <- 0
        der2p2.derdermu2sigma2 <- 0
        
      }
      
      
      
      
      
      
    }else{
     
      
    # Piecewise-exponential approach
    if( MBS_TYPE == "PWE" ){
      
      # GBS:
      # mu2 ----> theta * exp( offset )
      mu2 <- exp(eta2 + PAMM_offset)
      
      # GBS: I had to move ifef up to here! 
      mu2 <- ifef(mu2)
      
      dermu2.dereta2 <- mu2
      der2mu2.dereta2eta2 <- mu2
      
      
      dersigma2.dersigma2.st  <- 0  
      dersigma2.dersigma2.st2 <- 0
      
      # GBS: This check is not necessary but I'll leave it here
      if(max(y2) > 170){
        
        prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
        mu2 <- mpfr(mu2, prec)
        y2  <- mpfr( y2, prec)   
        
        
      }        
      
      
      ###########################################################################
      ###########################################################################
      # The definition of these terms is the following: 
      # exp(-sum_j mu2_ij ) ---> scalar
      Term1 <- function(mu2_ij){
        
        t1 <- exp( - sum(mu2_ij) )
        
        
        # Output is a SCALAR
        return(t1)
      }
      
      
      # sum_j ( mu2_ij x_ij x_ij^T ) ----> matrix
      Term2 <- function(mu2_ij, cov_vec){
        
        if(is.null(dim(cov_vec))){
          
          t2 <- mu2_ij * tcrossprod( as.vector(cov_vec), 
                                     as.vector(cov_vec) )
          
        }else{
          
          # should be a sum of j(i) matrices 
          t2 <- Reduce("+",
                       lapply(1:nrow(cov_vec),
                              function(i) 
                                mu2_ij[i] * tcrossprod( cov_vec[i,], 
                                                        cov_vec[i,]) 
                       ))
          
          
        }
        
        return(t2)
        
      }
      
      
      # sum_j ( mu2_ij x_ij ) ---> vector
      Term3 <- function(mu2_ij, cov_vec){
        
        
        # check of length
        if(is.null(dim(cov_vec))){
          
          t3 <- mu2_ij * cov_vec
          
        }else{
          
          t3 <- colSums( mu2_ij * cov_vec )
          
        }
        
        
        # output is a VECTOR
        return(t3)
      }
      ###########################################################################
      ###########################################################################
      
      # GBS: compute these quantities:
      # this is a scalar!
      terms1 <- c(sapply(ListOfIDs, 
                         function(i) 
                           Term1(mu2[i]))
      )
      
      
      # This is a matrix!
      terms2 <- lapply(ListOfIDs, 
                       function(i) 
                         Term2(mu2[i], X2[i,])
      )
      
      # This is a vector!
      terms3 <- t(sapply(ListOfIDs, 
                         function(i) 
                           Term3(mu2[i], X2[i,]))
      )
      
      # GBS: Carry out the ifef() checks of the terms in HERE!
      terms1 <- ifef(terms1)
      
      
      ###########################################################################
      ###########################################################################
      ###########################################################################
      
      pdf_term <- function(delta_iji, term1_i, mu2_iji){
        
        pdf <- ifelse(delta_iji == 0, 
                      term1_i, 
                      term1_i * mu2_iji)
        
        return(pdf)
        
      }
      
      cdf_term <- function(delta_iji, term1_i, mu2_iji){
        
        cdf <- ifelse(delta_iji == 0, 
                      term1_i,
                      (1 + mu2_iji) * term1_i)
        
        return(cdf)
        
      }
      
      ###########################################################################
      ###########################################################################
      ###########################################################################
      
      # extract the mu2_iji (i.e. last of the sequence of length j(i) per individual)
      mu2_iji <- mu2[iji_indices]
      
      # Compute PDF:
      pdf2 <- pdf_term(y2_iji, terms1, mu2_iji)
      
      
      derpdf2.derbeta_FUNC <- function(delta_iji, term1_i, term3_i, mu2_iji, x2_iji, indices_zero){
        
        df2_dbeta2 <- matrix(0, nrow = length(delta_iji), ncol = ncol(x2_iji))
        
        delta_iszero <- indices_zero # which(delta_iji == 0)
        
        # censored individuals
        df2_dbeta2[delta_iszero,] <-  as.numeric(-1) * as.numeric( term1_i[delta_iszero] ) * term3_i[delta_iszero,]  
        
        # non-censored individuals
        #df2_dbeta2[-delta_iszero,] <- as.numeric(term1_i[-delta_iszero]) * as.numeric(mu2_iji[-delta_iszero]) * ( -term3_i[-delta_iszero,] + x2_iji[-delta_iszero,] )
        df2_dbeta2[-delta_iszero,] <- as.numeric(term1_i[-delta_iszero]) * mu2_iji[-delta_iszero] * ( -term3_i[-delta_iszero,] + x2_iji[-delta_iszero,] )
        
        return(df2_dbeta2)
        
      }
      
      derpdf2.derbeta2     <- derpdf2.derbeta_FUNC(delta_iji = y2_iji,
                                                   term1_i = terms1,
                                                   term3_i = terms3, 
                                                   mu2_iji = mu2_iji,
                                                   x2_iji = X2_iji, 
                                                   indices_zero = indices_zeros)
      
      der2pdf2.derbetbet2_FUNC <- function(y2_iji, mu2_iji, term1_i, term2_i, term3_i, x2_iji){
        
        # check which is censored, which is not censored
        delta_iszero <- (y2_iji == 0)
        
        d2f2_dbb <- sapply(1:length(y2_iji),
                           function(i) 
                             
                             if(delta_iszero[i]){
                               #tcrossprod( term3_i[i,], term1_i[i] * term3_i[i,] ) + (-1) * term1_i[ i ] * term2_i[[i]]
                               ( tcrossprod( term3_i[i,], term3_i[i,] ) - term2_i[[i]] ) * as.numeric(term1_i[i])
                               
                             }else{
                               # tcrossprod( ( -term3_i[i,] + x2_iji[ i, ] ), term1_i[ i ] * mu2_iji[ i ] * ( -term3_i[i,] + x2_iji[ i, ] ) ) 
                               # -
                               #   term1_i[ i ] * mu2_iji[ i ] * term2_i[[i]]
                               ( tcrossprod( (-term3_i[i,] + x2_iji[i,]), (-term3_i[i,] + x2_iji[i,]) ) - term2_i[[i]] ) * term1_i[i] * mu2_iji[i]
                               
                             },
                           simplify = FALSE
                           
                           
        )
        
        
        return(d2f2_dbb)
        
      }
      
      der2pdf2.dermu2       <- der2pdf2.derbetbet2_FUNC(y2_iji = y2_iji, 
                                                        mu2_iji = mu2_iji, 
                                                        term1_i = terms1, 
                                                        term2_i = terms2, 
                                                        term3_i = terms3, 
                                                        x2_iji = X2_iji) 
      
      derpdf2.sigma2        <- 0
      der2pdf2.dersigma22   <- 0
      der2pdf2.mu2dersigma2 <- 0
      
      
      
      if(naive == FALSE){   # needs y2m 
        
        p2  <- cdf_term(y2_iji, terms1, mu2_iji)
        
        mu2 <- c(mu2)
        
        derp2.derbe_FUNC <- function(delta_iji, term1_i, term3_i, mu2_iji, x2_iji, dpdf2_dcoeff, indices_zero){
          
          dF2_dbeta2 <- matrix(0, 
                               nrow = length(delta_iji), 
                               ncol = ncol(x2_iji))
          
          delta_iszero <- indices_zero # which(delta_iji == 0)
          
          # censored individuals
          dF2_dbeta2[delta_iszero, ] <-  dpdf2_dcoeff[ delta_iszero, ]  
          
          # non-censored individuals
          #dF2_dbeta2[-delta_iszero,] <- -1 * as.numeric( term1_i[ -delta_iszero ] ) * term3_i[ -delta_iszero, ] + dpdf2_dcoeff[ -delta_iszero, ]
          #dF2_dbeta2[-delta_iszero, ] <- ( - 2 * term3_i[ -delta_iszero, ] + x2_iji[ -delta_iszero, ] ) * term1_i[ -delta_iszero ]
          dF2_dbeta2[-delta_iszero, ] <- ( mu2_iji[ -delta_iszero ] * ( term3_i[ -delta_iszero, ] + x2_iji[ -delta_iszero, ] ) - term3_i[ -delta_iszero, ] ) * term1_i[ -delta_iszero ]
          
          return(dF2_dbeta2)
          
        }
        
        derp2.dermu2           <- derp2.derbe_FUNC(delta_iji = y2_iji, 
                                                   term1_i = terms1, 
                                                   term3_i = terms3, 
                                                   mu2_iji = mu2_iji, 
                                                   x2_iji = X2_iji, 
                                                   dpdf2_dcoeff = derpdf2.derbeta2, 
                                                   indices_zero = indices_zeros)
        
        der2p2.derbebeT_FUNC       <- function(y2_iji, mu2_iji, term1_i, term2_i, term3_i, x2_iji, d2pdf2_dcoefcoef){
          
          # check cases of end of sequence of censoring indicators
          # case 0
          # pass through the case zero
          delta_iszero <- (y2_iji == 0)
          
          d2F2_dbb <- sapply(1:length(y2_iji),
                             function(i) 
                               
                               if(delta_iszero[i]){
                                 
                                 d2pdf2_dcoefcoef[[i]]
                                 
                               }else{
                                 
                                 # # simply hessian of pdf (censored) + pdf( non-censored )
                                 # ( ( tcrossprod( term3_i[i,], term3_i[i,] ) - term2_i[[i]] ) +     
                                 # ( tcrossprod( ( -term3_i[i,] + x2_iji[i,] ), ( -term3_i[i,] + x2_iji[i,] ) ) - term2_i[[i]] ) * mu2_iji[i] ) * term1_i[i]
                                  
                                 term1_i[i] * ( ( tcrossprod( term3_i[i,], term3_i[i,] ) - term2_i[[i]] ) + mu2_iji[i]*( tcrossprod( ( -term3_i[i,] + x2_iji[i,] ), ( -term3_i[i,] + x2_iji[i,] ) ) - term2_i[[i]] )   )
                                 
                                 },
                             simplify = FALSE
                             
                             
          )
          
          
          return(d2F2_dbb)
          
        }
        
        der2p2.dermu22           <- der2p2.derbebeT_FUNC(y2_iji = y2_iji, 
                                                         mu2_iji = mu2_iji, 
                                                         term1_i = terms1, 
                                                         term2_i = terms2,
                                                         term3_i = terms3, 
                                                         x2_iji = X2_iji, 
                                                         d2pdf2_dcoefcoef = der2pdf2.dermu2)
        
        # Some stuff w.r.t. sigma that is not necessary for us.
        derp2.dersigma2        <- 0
        der2p2.dersigma22      <- 0
        der2p2.derdermu2sigma2 <- 0
        
        
        
        
        
      }
    }
    
    
    # Discrete-time survival approach
    if( MBS_TYPE == "DTSOLD" ){
      
      # CLOG-LOG LINK
      # GBS: Discrete time survival approach:
      # mu2 ----> exp( eta2 )
      mu2 <- exp(eta2) 
      
      # GBS: I had to move ifef up to here! 
      mu2 <- ifef(mu2)
      
      # mu2_iji (i.e. last of the sequence of length j(i) per individual)
      mu2_iji <- mu2[iji_indices]
      
      # derivatives w.r.t. eta2 are just passed through. These won't be used ANYWAY. 
      dermu2.dereta2 <- mu2
      der2mu2.dereta2eta2 <- mu2
      
      # no sigma parameter in these models
      dersigma2.dersigma2.st  <- 0  
      dersigma2.dersigma2.st2 <- 0
      
      # GBS: This check is not necessary but I'll leave it here
      if(max(y2) > 170){
        
        prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
        mu2 <- mpfr(mu2, prec)
        y2  <- mpfr( y2, prec)   
        
        
      }        
      
      ###########################################################################
      ###########################################################################
      # Some helper functions!
      
      # The definition of these terms in the discrete time survival approach is the following: 
      # exp(-sum_j mu2_ij ) ---> scalar (sum up to the j(i)-1 entry!)
      Term1 <- function(mu2_ij){
        
        # always sum-up this scalar up to the second to last entry!
        t1 <- exp( - sum( mu2_ij[ -length(mu2_ij) ] ) )
        
        # Output is a SCALAR
        return(t1)
      }
      
      # this function produces a list of matrices!
      # sum_j up to j(i)-1!!!! ( mu2_ij x_ij x_ij^T ) ----> sum of j(i)-1 matrices
      Term2 <- function(mu2_ij, cov_vec){
        
        # GBS: I added this:
        length_of_sequence_minus1 <- nrow(cov_vec) - 1
        
        # sequence of only ONE interval
        if(is.null(dim(cov_vec))){
          
          # this one works for sequences of length 1! term2.5 is NOT NEEDED in those cases
          t2 <- mu2_ij * tcrossprod( as.vector(cov_vec), 
                                     as.vector(cov_vec) )
          
        }else if(nrow(cov_vec) == 2){
          
          
          # should be a sum of j(i)-1 matrices 
          t2 <- Reduce("+",
                       lapply(1:length_of_sequence_minus1,
                              function(i) 
                                mu2_ij[i] * tcrossprod( cov_vec[i,], 
                                                        cov_vec[i,]) 
                       ))
          
          
        }else{
          
          
          # should be a sum of j(i)-1 matrices 
          t2 <- Reduce("+",
          # GBS: I changed the nrow(cov_vec) - 1 here
          #             lapply(1:(nrow(cov_vec) - 1),
                        lapply(1:length_of_sequence_minus1,
                              function(i) 
                                mu2_ij[i] * tcrossprod( cov_vec[i,], 
                                                        cov_vec[i,]) 
                       ))
          
          
        }
        
        return(t2)
        
      }
      
      # ( mu2_ij x_ij x_ij^T )  ----> the missing matrix of the j(i)-th interval
      # this little function DOES NOT require index manipulation!
      Term2.5 <- function(mu2_iji, cov_vec_iji){
        
        # this only uses THE LAST vector! 
        term2.5 <- mu2_iji * tcrossprod(as.vector(cov_vec_iji), 
                                        as.vector(cov_vec_iji))
        
        return(term2.5)
        
      }
      
      # sum_j ( mu2_ij x_ij ) ---> vector
      Term3 <- function(mu2_ij, cov_vec){
        
        
        # check of length
        if(is.null(dim(cov_vec))){
          
          # for sequences of length 1 it doesn't matter.
          t3 <- mu2_ij * cov_vec
          
        }else{
          
          last_entry <- nrow(cov_vec)
          
          # if the sequence has TWO entries, colsums won't work....
          # special case for sequences of length TWO:
          if(nrow(cov_vec) == 2){
            
            t3 <-  c(mu2_ij[ -last_entry ]) * cov_vec[ -last_entry, ] 
            
          }else{
            
            # sum up to the SECOND TO LAST ENTRY (j(i)-1)!
            t3 <- colSums( c(mu2_ij[ -last_entry ]) * cov_vec[ -last_entry, ] )
            
          }
          
        }
        
        # output is a VECTOR
        return(t3)
      }
      
      ###########################################################################
      ###########################################################################
      
      # GBS: compute these little quantities:
      # this is a scalar!
      terms1 <- c(sapply(ListOfIDs, 
                         function(i) 
                           Term1(mu2[i]))
                  )
      
      # This is a (list of) matrix!
      terms2 <- lapply(ListOfIDs, 
                       function(i) 
                         Term2(mu2[i], 
                               X2[i,])
                       )
      
      # This is a list of matrices that only includes the j(i)-term!
      terms2.5 <- lapply(1:length(ListOfIDs),
                         function(i)
                           Term2.5(mu2_iji[i], X2_iji[i,])
                         )
      
      # This is a vector!
      terms3 <- t(sapply(ListOfIDs, 
                         function(i) 
                           Term3(mu2[i], 
                                 X2[i,]))
                  )
      
      # GBS: Carry out the ifef() checks of the terms in HERE!
      terms1 <- ifef(terms1)
      
      # GBS: 
      # PDF
      pdf_FUNC <-  function(y2_iji, mu2, term1, length_one_sequences, iji_indices){
        
        pdf <- numeric(length(y2_iji))
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          # all terms of the PDF are created like this:
          pdf <- ifelse(y2_iji == 1, 
                        #
                        # Ends in 1
                        term1 - term1 * exp( - mu2[iji_indices] ),
                        #
                        # Ends in zero
                        term1 * exp( - mu2[iji_indices] )
          )
          
        }else{
          
          # Sequences of length 1
          pdf[length_one_sequences] <- ifelse(y2_iji[length_one_sequences] == 1,
                                              #
                                              1 - exp( - mu2[iji_indices][length_one_sequences] ), # cloglog(eta)
                                              #
                                              exp( - mu2[iji_indices][length_one_sequences] )      # 1 - cloglog(eta)
          )
          
          # Sequences of length larger than 1
          pdf[-length_one_sequences] <- ifelse(y2_iji[-length_one_sequences] == 1, 
                                               #
                                               # Ends in 1
                                               term1[-length_one_sequences] - term1[-length_one_sequences] * exp( - mu2[iji_indices][-length_one_sequences] ),
                                               #
                                               # Ends in zero
                                               term1[-length_one_sequences] * exp( - mu2[iji_indices][-length_one_sequences] )
          )
          
          
        }
        
        
        return(pdf)
        
      }
      
      # CDF
      cdf_FUNC <-  function(y2_iji, mu2, term1, length_one_sequences, iji_indices, pdf_term){
        
        cdf <- numeric(length(y2_iji))
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          # all terms of the PDF are created like this:
          cdf <- ifelse(y2_iji == 1, 
                        #
                        # Ends in 1
                        term1,
                        #
                        # Ends in zero
                        pdf_term
          )
          
        }else{
          
          # Sequences of length 1
          cdf[length_one_sequences] <- ifelse(y2_iji[length_one_sequences] == 1,
                                              #
                                              1, # 1 - cloglog(eta) + cloglog(eta) = 1.
                                              #
                                              pdf_term[length_one_sequences]  # 1 - cloglog(eta)
          )
          
          # Sequences of length larger than 1
          cdf[-length_one_sequences] <- ifelse(y2_iji[-length_one_sequences] == 1, 
                                               #
                                               # Ends in 1
                                               term1[-length_one_sequences],
                                               #
                                               # Ends in zero
                                               pdf_term[-length_one_sequences]
          )
          
          
        }
        
        
        return(cdf)
      }
      
      ###########################################################################
      ###########################################################################
      ###########################################################################
      
      # GBS:   
      pdf2 <- pdf_FUNC(y2_iji = y2_iji, mu2 = mu2, 
                       term1 = terms1, 
                       length_one_sequences = length_one_sequences, 
                       iji_indices = iji_indices)
      
      
      derpdf2.derbeta_FUNC <- function(term1, term3, mu2_iji, x2_iji, y2_iji, length_one_sequences){
        
        der_pdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
        
        sample_IDs <- 1:nrow(term3)
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          der_pdf <- t(sapply(1:length(y2_iji), 
                              function(i)
                                if(y2_iji[i] == 1){ 
                                  #
                                  # Ends in 1
                                  term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,])     -    term1[i] * term3[i,]
                                  #
                                }else{
                                  #
                                  # Ends in zero
                                  #- term1[i] * exp( - mu2_iji[i] ) * term3[i,]
                                 - term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,]) 
                                }
          ))
          
          # There are sequences of length 1 and others with length > 1.  
        }else{
          
          der_pdf[length_one_sequences, ] <- t(sapply(length_one_sequences, 
                                                      function(i)
                                                        if(y2_iji[i] == 1){
                                                          #
                                                          # ends in 1
                                                          c(exp( - mu2_iji[i] )) * terms3[i,]
                                                          #
                                                        }else{
                                                          #
                                                          # ends in zero
                                                          (-1) * c(exp( - mu2_iji[i] )) * terms3[i,]
                                                        },
                                                      simplify = TRUE)
                                               )
          
          # Sequences of length larger than 1
          der_pdf[-length_one_sequences,] <- t(sapply(sample_IDs[-length_one_sequences], function(i)
            if(y2_iji[i] == 1){
              #
              # Ends in 1
              term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,])   -   term1[i] * term3[i,]
              #
            }else{
              ##
              # Ends in zero
              #- term1[i] * exp( - mu2_iji[i] )* term3[i,]
              (-1) * term1[i] * exp( - mu2_iji[i] ) * (term3[i,] + mu2_iji[i] * x2_iji[i,])
            }, 
            simplify = TRUE)
          )
        }
        
        return(der_pdf)
      }
      
      derpdf2.derbeta2     <- derpdf2.derbeta_FUNC(term1 = terms1, term3 = terms3, mu2_iji = mu2_iji, x2_iji = X2_iji, y2_iji = y2_iji, length_one_sequences = length_one_sequences)
      
      der2pdf2.derbetbet2_FUNC <- function(term1, term2, term2.5, term3, y2_iji, mu2_iji, x2_iji, length_one_sequences){
        
        d2pdf2 <- vector(mode = "list", length = nrow(term3))
        
        sample_IDs <- 1:nrow(term3)
        
        # there are NO SEQUENCES OF LENGTH 1
        if(length(length_one_sequences) == 0){
          
          d2pdf2 <- sapply(1:length(y2_iji), 
                           function(i)
                             if(y2_iji[i] == 1){ 
                               #
                               # Ends in 1
                                 # term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] ) -
                                 # term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) -
                                 # term1[i] * term2[[i]]  +
                                 # term1[i] * tcrossprod( term3[i,] , term3[i,] )
                               # term1[i] * ( tcrossprod( term3[i,] , term3[i,] ) - term2[[i]] ) - 
                               # term1[i] * exp( - mu2_iji[i] ) * ( tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) + 
                               #                                      ( term2[[i]] + term2.5[[i]] ) )
                               term1[i] * ( tcrossprod( term3[i,] , term3[i,] ) - term2[[i]] ) - 
                               term1[i] * exp( - mu2_iji[i] ) * ( tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) - 
                                                                      ( term2[[i]] + term2.5[[i]] ) )
                               
                               
                             }else{
                               #
                               # Ends in zero
                               # term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ,  (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) - 
                               # term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] )
                               term1[i] * exp( - mu2_iji[i] ) * (tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ,  (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) - ( term2[[i]] + term2.5[[i]] ))
                             },
                           simplify = FALSE
          )
          
          # There are sequences of length 1 and others with length > 1.  
        }else{
          
          # Sequences of length 1
          d2pdf2[length_one_sequences] <- sapply(length_one_sequences, 
                                                 function(i)
                                                   if(y2_iji[i] == 1){
                                                     #
                                                     # ends in 1
                                                    (-1)*c(exp( - mu2_iji[i] )) * tcrossprod( terms3[i,], terms3[i,] ) +
                                                       exp( - mu2_iji[i] ) * terms2[[i]]
                                                     #
                                                   }else{
                                                     #
                                                     # ends in zero
                                                     c(exp( - mu2_iji[i] )) * tcrossprod( terms3[i,], terms3[i,] ) - 
                                                       exp( - mu2_iji[i] ) *  terms2[[i]]
                                                   },
                                                 simplify = FALSE
          )
          
          # Sequences of length larger than 1
          d2pdf2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], function(i)
            if(y2_iji[i] == 1){
              #
              # Ends in 1
              # term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] ) -
              # term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) -
              # term1[i] * term2[[i]]  + term1[i] * tcrossprod( term3[i,] , term3[i,] )
              # term1[i] * ( tcrossprod( term3[i,] , term3[i,] ) - term2[[i]] ) - 
              # term1[i] * exp( - mu2_iji[i] ) * ( tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) + 
              #                           ( term2[[i]] + term2.5[[i]] ) )
              term1[i] * ( tcrossprod( term3[i,] , term3[i,] ) - term2[[i]] ) - 
              term1[i] * exp( - mu2_iji[i] ) * ( tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ) - 
                                                     ( term2[[i]] + term2.5[[i]] ) )
              #
            }else{
              ##
              # Ends in zero
              # term1[i] * exp( - mu2_iji[i] ) * tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) , (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) - 
              # term1[i] * exp( - mu2_iji[i] ) * ( term2[[i]] + term2.5[[i]] )
              term1[i] * exp( - mu2_iji[i] ) * (tcrossprod( (term3[i,] + mu2_iji[i] * x2_iji[i,] ) ,  (term3[i,] + mu2_iji[i] * x2_iji[i,]) ) - ( term2[[i]] + term2.5[[i]] ))
            }, 
            simplify = FALSE
          )
          
          
          
          
        }
        
        
        return(d2pdf2)
      }
      
      der2pdf2.dermu2       <- der2pdf2.derbetbet2_FUNC(term1 = terms1, term2 = terms2, term2.5 = terms2.5, term3 = terms3, y2_iji = y2_iji, mu2_iji = mu2_iji, x2_iji = X2_iji, length_one_sequences = length_one_sequences)
      
      
      # no sigma parameter in these approaches
      derpdf2.sigma2        <- 0
      der2pdf2.dersigma22   <- 0
      der2pdf2.mu2dersigma2 <- 0
      
      
      
      if(naive == FALSE){   # needs y2m 
        
        p2 <- cdf_FUNC(y2_iji = y2_iji, mu2 = mu2, term1 = terms1, length_one_sequences = length_one_sequences, iji_indices = iji_indices, pdf_term = pdf2)
        
        mu2 <- c(mu2)
        
        derp2.derbe_FUNC <- function(term1, term3, mu2_iji, x2_iji, y2_iji, length_one_sequences, derpdf2_terms){
          
          der_cdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
          
          sample_IDs <- 1:nrow(term3)
          
          # there are NO SEQUENCES OF LENGTH 1
          if(length(length_one_sequences) == 0){
            
            der_pdf <- t(sapply(1:length(y2_iji), 
                                function(i)
                                  if(y2_iji[i] == 1){ 
                                    #
                                    # Ends in 1
                                    - term1[i] * term3[i,]
                                  }else{
                                    #
                                    # Ends in zero
                                    derpdf2_terms[i,]
                                  }, 
                                simplify = TRUE)
            )
            
            
            # There are sequences of length 1 and others with length > 1.  
          }else{
            
            # sequences of length 1
            der_cdf[length_one_sequences, ] <- t(sapply(length_one_sequences, 
                                                        function(i)
                                                          if(y2_iji[i] == 1){
                                                            #
                                                            # ends in 1
                                                            rep(0, ncol(x2_iji))
                                                            #
                                                          }else{
                                                            #
                                                            # ends in zero
                                                            derpdf2_terms[i, ]
                                                          },
                                                        simplify = TRUE)
            )
            
            # Sequences of length larger than 1
            der_cdf[-length_one_sequences,] <- t(sapply(sample_IDs[-length_one_sequences], 
                                                        function(i)
                                                          if(y2_iji[i] == 1){
                                                            #
                                                            # Ends in 1
                                                            -term1[ i ] * term3[ i, ]
                                                            #
                                                          }else{
                                                            #
                                                            # Ends in zero
                                                            derpdf2_terms[ i, ]
                                                          }, 
                                                        simplify = TRUE)
                                                 )
            }
          
          return(der_cdf)
          
        }
        
        
        derp2.dermu2           <- derp2.derbe_FUNC(term1 = terms1, term3 = terms3, mu2_iji = mu2_iji, x2_iji = X2_iji, y2_iji = y2_iji, length_one_sequences = length_one_sequences, derpdf2_terms = derpdf2.derbeta2)
        
        der2p2.derbebeT_FUNC       <- function(term1, term2, term2.5, term3, y2_iji, mu2_iji, x_iji, length_one_sequences, der2pdf2_terms){
          
          d2p2 <- vector(mode = "list", length = nrow(term3))
          
          sample_IDs <- 1:nrow(term3)
          
          # there are NO SEQUENCES OF LENGTH 1
          if(length(length_one_sequences) == 0){
            
            d2p2 <- sapply(1:length(y2_iji), 
                           function(i)
                             if(y2_iji[i] == 1){ 
                               #
                               # Ends in 1
                               - term1[i] * term2[[i]]  +
                                 term1[i] * tcrossprod( term3[i,] , term3[i,] )
                               #
                             }else{
                               #
                               # Ends in zero
                               der2pdf2_terms[[i]]
                             },
                           simplify = FALSE
            )
            
            # There are sequences of length 1 and others with length > 1.  
          }else{
            
            # Sequences of length 1
            d2p2[length_one_sequences ] <- sapply(length_one_sequences, 
                                                  function(i)
                                                    if(y2_iji[i] == 1){
                                                      #
                                                      # ends in 1
                                                      matrix(0, ncol = ncol(x_iji), nrow = ncol(x_iji))
                                                      #
                                                    }else{
                                                      #
                                                      # ends in zero
                                                      der2pdf2_terms[[i]]
                                                    },
                                                  simplify = FALSE
            )
            
            
            
            
            # Sequences of length larger than 1
            d2p2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], 
                                                  function(i)
                                                    if(y2_iji[i] == 1){
                                                      #
                                                      # Ends in 1
                                                      - term1[i] * term2[[i]]  +
                                                        term1[i] * tcrossprod( term3[i,] , term3[i,] )
                                                      #
                                                    }else{
                                                      ##
                                                      # Ends in zero
                                                      der2pdf2_terms[[i]]
                                                    }, 
                                                  simplify = FALSE
                  )
            }
          
          return(d2p2)
        }
        
        der2p2.dermu22           <- der2p2.derbebeT_FUNC(term1 = terms1, term2 = terms2, term2.5 = terms2.5, term3 = terms3, y2_iji = y2_iji, mu2_iji = mu2_iji, x_iji = X2_iji, length_one_sequences = length_one_sequences, der2pdf2_terms = der2pdf2.dermu2)
        
        # Some stuff w.r.t. sigma that is not necessary for us.
        derp2.dersigma2        <- 0
        der2p2.dersigma22      <- 0
        der2p2.derdermu2sigma2 <- 0
        
      }
    }
      
      
      # Discrete-time survival approach
    if( MBS_TYPE == "DTS" ){
        
        # CLOG-LOG LINK
        # GBS: Discrete time survival approach:
        # mu2 ----> exp( eta2 )
        mu2 <- exp(eta2) 
        
        # GBS: I had to move ifef up to here! 
        mu2 <- ifef(mu2)
        
        # mu2_iji (i.e. last of the sequence of length j(i) per individual)
        mu2_iji <- mu2[iji_indices]
        
        # derivatives w.r.t. eta2 are just passed through. These won't be used ANYWAY. 
        dermu2.dereta2 <- mu2
        der2mu2.dereta2eta2 <- mu2
        
        # no sigma parameter in these models
        dersigma2.dersigma2.st  <- 0  
        dersigma2.dersigma2.st2 <- 0
        
        # GBS: This check is not necessary but I'll leave it here
        if(max(y2) > 170){
          
          prec <- pmax(53, getPrec(mu2), getPrec(y2))
          
          mu2 <- mpfr(mu2, prec)
          y2  <- mpfr( y2, prec)   
          
          
        }        
        
        ###########################################################################
        ###########################################################################
        # Some helper functions!
        
        # sum_j mu2_ij ---> scalar (sum up to the j(i)) (exp is applied later!!!!)
        Term1 <- function(mu2_ij){
          
          # always sum-up this scalar up to the second to last entry!
          t1 <-  sum( mu2_ij ) 
          
          # Output is a SCALAR
          return(t1)
        }
        
        # sum_j up to j(i)-1!!!! ( mu2_ij x_ij x_ij^T ) ----> sum of j(i) matrices
        Term2 <- function(mu2_ij, cov_vec){
          
          # sequence of only ONE interval
          if(is.null(dim(cov_vec))){
            
            # this one works for sequences of length 1! term2.5 is NOT NEEDED in those cases
            t2 <- mu2_ij * tcrossprod( as.vector(cov_vec), as.vector(cov_vec) )
            
          }else{
            
            # should be a sum of j(i)-1 matrices 
            t2 <- Reduce("+", lapply(1:nrow(cov_vec), function(i) 
              
              mu2_ij[i] * tcrossprod( cov_vec[i,], cov_vec[i,] ) )
              
            )}
          
          return(t2)
        }
        
        # sum_j ( mu2_ij x_ij ) ---> vector
        Term3 <- function(mu2_ij, cov_vec){
          
          # check of length
          if(is.null(dim(cov_vec))){
            
            # for sequences of length 1 it doesn't matter.
            t3 <- mu2_ij * cov_vec
            
          }else{
            
            # sum up to the SECOND TO LAST ENTRY (j(i)-1)!
            t3 <- colSums( c( mu2_ij ) * cov_vec )
            
          }
          
          # output is a VECTOR
          return(t3)
        }
        
        ###########################################################################
        ###########################################################################
        
        # GBS: compute these little quantities:
        terms1 <- c(sapply(ListOfIDs, 
                           function(i) 
                             Term1(mu2[i])))
        
        # This is a (list of) matrix!
        terms2 <- lapply(ListOfIDs, 
                         function(i) 
                           Term2(mu2[i], 
                                 X2[i,]))
        
        # This is a vector!
        terms3 <- t(sapply(ListOfIDs, 
                           function(i) 
                             Term3(mu2[i], 
                                   X2[i,])))
        
        
        # GBS: 
        # PDF
        pdf_FUNC <-  function(y2_iji, term1, mu2_iji){
          
          pdf <- numeric(length(y2_iji))
          
          # there are NO SEQUENCES OF LENGTH 1
          #if(length(length_one_sequences) == 0){
          # all terms of the PDF are created like this:
          pdf <- ifelse(y2_iji == 1, 
                        #
                        # Ends in 1 / not censored
                        exp( - ( term1 - mu2_iji ) ) - exp( - ( term1 ) ),
                        #
                        # Ends in zero / censored
                        exp( - ( term1 ) )
          )
          # }else{
          #   
          #   # Sequences of length 1
          #   pdf[length_one_sequences] <- ifelse(y2_iji[length_one_sequences] == 1,
          #                                       #
          #                                       1 - exp( - mu2_iji[length_one_sequences] ), # cloglog(eta)
          #                                       #
          #                                       exp( - mu2_iji[length_one_sequences] )      # 1 - cloglog(eta)
          #   )
          #   
          #   # Sequences of length larger than 1
          #   pdf[-length_one_sequences] <- ifelse(y2_iji[-length_one_sequences] == 1, 
          #                                        #
          #                                        # Ends in 1
          #                                        exp( -( term1[-length_one_sequences] - mu2_iji[-length_one_sequences] ) ) - exp( -( term1[-length_one_sequences] ) ),
          #                                        #
          #                                        # Ends in zero
          #                                        exp( -( term1[-length_one_sequences] ) )
          #   )
          #   
          #   
          # }
          
          return(pdf)
          
        }
        
        # CDF
        cdf_FUNC <-  function(y2_iji, mu2_iji, term1, pdf_term){
          
          cdf <- numeric(length(y2_iji))
          
          # # there are NO SEQUENCES OF LENGTH 1
          # if(length(length_one_sequences) == 0){
          
          # all terms of the PDF are created like this:
          cdf <- ifelse(y2_iji == 1, 
                        #
                        # Ends in 1
                        exp( - ( term1 - mu2_iji ) ),
                        #
                        # Ends in zero
                        pdf_term
          )
          
          # }else{
          #   
          #   # Sequences of length 1
          #   cdf[length_one_sequences] <- ifelse(y2_iji[length_one_sequences] == 1,
          #                                       #
          #                                       1, # 1 - cloglog(eta) + cloglog(eta) = 1.
          #                                       #
          #                                       pdf_term[length_one_sequences]  # 1 - cloglog(eta)
          #   )
          #   
          #   # Sequences of length larger than 1
          #   cdf[-length_one_sequences] <- ifelse(y2_iji[-length_one_sequences] == 1, 
          #                                        #
          #                                        # Ends in 1
          #                                        exp( - ( term1[-length_one_sequences] - mu2_iji[-length_one_sequences] ) ),
          #                                        #
          #                                        # Ends in zero
          #                                        pdf_term[-length_one_sequences]
          #   )
          # }
          
          
          return(cdf)
        }
        
        ###########################################################################
        ###########################################################################
        ###########################################################################
        
        # GBS:   
        pdf2 <- pdf_FUNC(y2_iji = y2_iji, term1 = terms1, mu2_iji = mu2_iji)
        
        
        
        derpdf2.derbeta_FUNC <- function(term1, term3, mu2_iji, x2_iji, y2_iji){
          
          der_pdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
          
          sample_IDs <- 1:nrow(term3)
          
          # # there are NO SEQUENCES OF LENGTH 1
          # if(length(length_one_sequences) == 0){
          
          der_pdf <- t(sapply(1:length(y2_iji), 
                              function(i)
                                if(y2_iji[i] == 1){ 
                                  #
                                  # Ends in 1
                                  - exp( - ( term1[i] - mu2_iji[i] ) )  *  ( term3[i,] - mu2_iji[i] * x2_iji[i,] ) + exp( - term1[i] ) * term3[i,] 
                                  #
                                }else{
                                  #
                                  # Ends in zero
                                  - exp( - term1[i] ) * ( term3[i,] ) 
                                }
          ))
          
          #   # There are sequences of length 1 and others with length > 1.  
          # }else{
          #   
          #   der_pdf[length_one_sequences, ] <- t(sapply(length_one_sequences, 
          #                                               function(i)
          #                                                 if(y2_iji[i] == 1){
          #                                                   #
          #                                                   # ends in 1
          #                                                   c(exp( - mu2_iji[i] )) * terms3[i,]
          #                                                   #
          #                                                 }else{
          #                                                   #
          #                                                   # ends in zero
          #                                                   (-1) * c(exp( - mu2_iji[i] )) * terms3[i,]
          #                                                 },
          #                                               simplify = TRUE)
          #   )
          #   
          #   # Sequences of length larger than 1
          #   der_pdf[-length_one_sequences,] <- t(sapply(sample_IDs[-length_one_sequences], function(i)
          #     if(y2_iji[i] == 1){
          #       #
          #       # Ends in 1
          #       - exp( -( term1[i] - mu2_iji[i] ) ) * ( term3[i,] - mu2_iji[i] * x2_iji[i,] ) + exp( - term1[i] ) * term3[i,]
          #       #
          #     }else{
          #       ##
          #       # Ends in zero
          #       (-1) * exp( - term1[i] ) * ( term3[i,] )
          #     }, 
          #     simplify = TRUE)
          #   )
          # }
          
          return(der_pdf)
        }
        
        derpdf2.derbeta2     <- derpdf2.derbeta_FUNC(term1 = terms1, term3 = terms3, 
                                                     mu2_iji = mu2_iji, x2_iji = X2_iji, y2_iji = y2_iji)
        
        
        der2pdf2.derbetbet2_FUNC <- function(term1, term2, term3, y2_iji, mu2_iji, x2_iji){
          
          d2pdf2 <- vector(mode = "list", length = nrow(term3))
          
          sample_IDs <- 1:nrow(term3)
          
          # # there are NO SEQUENCES OF LENGTH 1
          # if(length(length_one_sequences) == 0){
          
          d2pdf2 <- sapply(1:length(y2_iji), 
                           function(i)
                             if(y2_iji[i] == 1){ 
                               #
                               # Ends in 1
                               exp( - ( term1[i] - mu2_iji[i] ) ) * (tcrossprod( (term3[i,] - mu2_iji[i] * x2_iji[i,]),  (term3[i,] - mu2_iji[i] * x2_iji[i,]) ) -  ( term2[[i]] - mu2_iji[i] * tcrossprod( x2_iji[i,] , x2_iji[i,] ) ) ) - exp( - term1[i] ) * (tcrossprod( term3[i,] ,  term3[i,] ) -  term2[[i]] )
                               
                             }else{
                               #
                               # Ends in zero
                               exp( - term1[i] ) * (tcrossprod( term3[i,] ,  term3[i,] ) -  term2[[i]] )
                             },
                           simplify = FALSE
          )
          
          #   # There are sequences of length 1 and others with length > 1.  
          # }else{
          #   
          #   # Sequences of length 1
          #   d2pdf2[length_one_sequences] <- sapply(length_one_sequences, 
          #                                          function(i)
          #                                            if(y2_iji[i] == 1){
          #                                              #
          #                                              # ends in 1
          #                                              (-1)*c(exp( - mu2_iji[i] )) * tcrossprod( terms3[i,], terms3[i,] ) + exp( - mu2_iji[i] ) * terms2[[i]]
          #                                              #
          #                                            }else{
          #                                              #
          #                                              # ends in zero
          #                                              c(exp( - mu2_iji[i] )) * tcrossprod( terms3[i,], terms3[i,] ) - exp( - mu2_iji[i] ) *  terms2[[i]]
          #                                            },
          #                                          simplify = FALSE)
          #   
          #   # Sequences of length larger than 1
          #   d2pdf2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], function(i)
          #     if(y2_iji[i] == 1){
          #       #
          #       # Ends in 1
          #       exp( - ( term1[i] - mu2_iji[i] ) ) * (tcrossprod( (term3[i,] - mu2_iji[i] * x2_iji[i,]),  (term3[i,] - mu2_iji[i] * x2_iji[i,]) ) -  ( term2[[i]] - mu2_iji[i] * tcrossprod( x2_iji[i,] , x2_iji[i,] ) ) ) - exp( - term1[i] ) * (tcrossprod( term3[i,] ,  term3[i,] ) -  term2[[i]] )
          #       #
          #     }else{
          #       ##
          #       # Ends in zero
          #       exp( - term1[i] ) * (tcrossprod( term3[i,] ,  term3[i,] ) -  term2[[i]] )
          #     }, 
          #     simplify = FALSE)
          # }
          
          
          return(d2pdf2)
        }
        
        der2pdf2.dermu2       <- der2pdf2.derbetbet2_FUNC(term1 = terms1, term2 = terms2, term3 = terms3, 
                                                          y2_iji = y2_iji, mu2_iji = mu2_iji, x2_iji = X2_iji)
        
        
        # no sigma parameter in these approaches
        derpdf2.sigma2        <- 0
        der2pdf2.dersigma22   <- 0
        der2pdf2.mu2dersigma2 <- 0
        
        
        
        if(naive == FALSE){   # needs y2m 
          
          p2 <- cdf_FUNC(y2_iji = y2_iji, mu2_iji = mu2_iji, term1 = terms1, pdf_term = pdf2)
          
          
          derp2.derbe_FUNC <- function(term1, term3, mu2_iji, x2_iji, y2_iji, derpdf2_terms){
            
            der_cdf <- matrix(0, nrow = nrow(term3), ncol = ncol(term3))
            
            sample_IDs <- 1:nrow(term3)
            
            # # there are NO SEQUENCES OF LENGTH 1
            # if(length(length_one_sequences) == 0){
            
            der_cdf <- t(sapply(1:length(y2_iji), 
                                function(i)
                                  if(y2_iji[i] == 1){ 
                                    #
                                    # Ends in 1
                                    - exp( - ( term1[i] - mu2_iji[i] ) ) *( term3[i,] - mu2_iji[i]*x2_iji[i,] )
                                    
                                  }else{
                                    #
                                    # Ends in zero
                                    derpdf2_terms[i,]
                                    
                                  }, 
                                simplify = TRUE))
            
            
            #   # There are sequences of length 1 and others with length > 1.  
            # }else{
            #   
            #   # sequences of length 1
            #   der_cdf[length_one_sequences, ] <- t(sapply(length_one_sequences, 
            #                                               function(i)
            #                                                 if(y2_iji[i] == 1){
            #                                                   #
            #                                                   # ends in 1
            #                                                   rep(0, ncol(x2_iji))
            #                                                   #
            #                                                 }else{
            #                                                   #
            #                                                   # ends in zero
            #                                                   derpdf2_terms[i, ]
            #                                                 },
            #                                               simplify = TRUE))
            #   
            #   # Sequences of length larger than 1
            #   der_cdf[-length_one_sequences,] <- t(sapply(sample_IDs[-length_one_sequences], 
            #                                               function(i)
            #                                                 if(y2_iji[i] == 1){
            #                                                   #
            #                                                   # Ends in 1
            #                                                   -exp( -( term1[i] - mu2_iji[i] ) ) * ( term3[i,] - mu2_iji[i] * x2_iji[i,] )
            #                                                   #
            #                                                 }else{
            #                                                   #
            #                                                   # Ends in zero
            #                                                   derpdf2_terms[ i, ]
            #                                                 }, 
            #                                               simplify = TRUE))
            # }
            
            
            return(der_cdf)
          }
          
          
          
          derp2.dermu2           <- derp2.derbe_FUNC(term1 = terms1, term3 = terms3, 
                                                     mu2_iji = mu2_iji, x2_iji = X2_iji, y2_iji = y2_iji, 
                                                     derpdf2_terms = derpdf2.derbeta2)
          
          
          der2p2.derbebeT_FUNC       <- function(term1, term2, term3, y2_iji, mu2_iji, x2_iji, der2pdf2_terms){
            
            d2p2 <- vector(mode = "list", length = nrow(term3))
            
            sample_IDs <- 1:nrow(term3)
            
            # # there are NO SEQUENCES OF LENGTH 1
            # if(length(length_one_sequences) == 0){
            
            d2p2 <- sapply(1:length(y2_iji), 
                           function(i)
                             if(y2_iji[i] == 1){ 
                               #
                               # Ends in 1
                               exp( - ( term1[i] - mu2_iji[i] ) ) * ( tcrossprod( (term3[i,] - mu2_iji[i] * x2_iji[i,]) , (term3[i,] - mu2_iji[i] * x2_iji[i,]) ) - (  term2[[i]] - mu2_iji[i] * tcrossprod( x2_iji[i,], x2_iji[i,] ) ) )
                               #
                             }else{
                               #
                               # Ends in zero
                               der2pdf2_terms[[i]]
                               
                             }, simplify = FALSE)
            
            # There are sequences of length 1 and others with length > 1.  
            # }else{
            #   
            #   # Sequences of length 1
            #   d2p2[length_one_sequences ] <- sapply(length_one_sequences, 
            #                                         function(i)
            #                                           if(y2_iji[i] == 1){
            #                                             #
            #                                             # ends in 1
            #                                             matrix(0, ncol = ncol(x_iji), nrow = ncol(x_iji))
            #                                             #
            #                                           }else{
            #                                             #
            #                                             # ends in zero
            #                                             der2pdf2_terms[[i]]
            #                                           },
            #                                         simplify = FALSE
            #   )
            #   
            #   
            #   
            #   
            #   # Sequences of length larger than 1
            #   d2p2[-length_one_sequences] <- sapply(sample_IDs[-length_one_sequences], 
            #                                         function(i)
            #                                           if(y2_iji[i] == 1){
            #                                             #
            #                                             # Ends in 1
            #                                             - term1[i] * term2[[i]]  +
            #                                               term1[i] * tcrossprod( term3[i,] , term3[i,] )
            #                                             #
            #                                           }else{
            #                                             ##
            #                                             # Ends in zero
            #                                             der2pdf2_terms[[i]]
            #                                           }, 
            #                                         simplify = FALSE) }
            
            return(d2p2)
          }
          
          
          der2p2.dermu22           <- der2p2.derbebeT_FUNC(term1 = terms1, term2 = terms2, term3 = terms3, 
                                                           y2_iji = y2_iji, mu2_iji = mu2_iji, x2_iji = X2_iji, 
                                                           der2pdf2_terms = der2pdf2.dermu2)
          
          
          # Some stuff w.r.t. sigma that is not necessary for us.
          derp2.dersigma2        <- 0
          der2p2.dersigma22      <- 0
          der2p2.derdermu2sigma2 <- 0
          
        }
      }
    
    
    
  }
    # It looks like it can actually still use the poisson distribution. IMPRESSIVE!
  }else{
  
mu2 <- exp(eta2)
dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2)

dersigma2.dersigma2.st  <- 0  
dersigma2.dersigma2.st2 <- 0


if(max(y2) > 170){

prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
mu2 <- mpfr(mu2, prec)
y2  <- mpfr( y2, prec)        
        
}        
        
        
# exp(y2*log(mu2) - mu2 - log(gamma(y2 + 1)))
# should be more stable but looks the same
# from a few experiments
        
        
pdf2 <-  as.numeric( (exp(-mu2)*mu2^y2)/factorial(y2) )   

derpdf2.dermu2FUNCpo <- function(y2, mu2) exp(-mu2) * (mu2^(y2 - 1) * y2 - mu2^y2)/factorial(y2) 
derpdf2.dermu2       <- as.numeric( derpdf2.dermu2FUNCpo(y2, mu2) )
    
der2pdf2.dermu2FUNCpo <- function(y2, mu2) exp(-mu2) * (mu2^y2 + y2 * (mu2^(y2 - 2) * (y2 - 1) - 2 * mu2^(y2 - 1)))/factorial(y2)  
der2pdf2.dermu2       <- as.numeric( der2pdf2.dermu2FUNCpo(y2, mu2) )
    
derpdf2.sigma2        <- 0
der2pdf2.dersigma22   <- 0
der2pdf2.mu2dersigma2 <- 0



if(naive == FALSE){   # needs y2m 
 
p2  <- pPO(as.numeric(y2), mu = as.numeric(mu2)) 
 
mu2 <- c(mu2)

derp2.dermu2           <- rowSums( matrix(as.numeric(derpdf2.dermu2FUNCpo(y2m, mu2)), dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE ) 
derp2.dersigma2        <- 0
der2p2.dermu22         <- rowSums( matrix(as.numeric(der2pdf2.dermu2FUNCpo(y2m, mu2)),dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE ) 
der2p2.dersigma22      <- 0
der2p2.derdermu2sigma2 <- 0


                      
    
}

}

}



if(margin2 == "ZTP"){

mu2 <- exp(eta2)
dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2) 

dersigma2.dersigma2.st  <- 0
dersigma2.dersigma2.st2 <- 0

if(max(y2) > 170){

prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
mu2 <- mpfr(mu2, prec)
y2  <- mpfr( y2, prec) 

}


pdf2FUNCztp <- function(y2, mu2) mu2^y2/(exp(mu2)-1)*1/factorial(y2)  
pdf2        <- as.numeric( pdf2FUNCztp(y2, mu2) )  

derpdf2.dermu2FUNCztp <- function(y2, mu2) (mu2^(y2 - 1) * y2 - mu2^y2 * exp(mu2)/(exp(mu2) - 1))/(factorial(y2) * (exp(mu2) - 1))  
derpdf2.dermu2        <- as.numeric( derpdf2.dermu2FUNCztp(y2, mu2) )
    
der2pdf2.dermu2FUNCztp <- function(y2, mu2) (y2 * (mu2^(y2 - 2) * (y2 - 1) - mu2^(y2 - 1) * exp(mu2)/(exp(mu2) - 
    1)) - exp(mu2) * (mu2^(y2 - 1) * y2 + mu2^y2 - 2 * (mu2^y2 * 
    exp(mu2)/(exp(mu2) - 1)))/(exp(mu2) - 1))/(factorial(y2) * (exp(mu2) - 
    1))   
der2pdf2.dermu2        <- as.numeric( der2pdf2.dermu2FUNCztp(y2, mu2) ) 
    
derpdf2.sigma2        <- 0
der2pdf2.dersigma22   <- 0
der2pdf2.mu2dersigma2 <- 0


if(naive == FALSE){   #needs y2m

mu2 <- c(mu2)

p2  <- rowSums( matrix(as.numeric(pdf2FUNCztp(y2m, mu2)),dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE )

derp2.dermu2           <- rowSums( matrix(as.numeric(derpdf2.dermu2FUNCztp(y2m, mu2)), dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE )
derp2.dersigma2        <- 0
der2p2.dermu22         <- rowSums( matrix(as.numeric(der2pdf2.dermu2FUNCztp(y2m, mu2)),dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE )
der2p2.dersigma22      <- 0
der2p2.derdermu2sigma2 <- 0
                      
    
                   }

}




####
####


if(margin2 == "DGP0"){

mu2 <- exp(eta2) # this is sigma in the notation of the distribution
dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2)

dersigma2.dersigma2.st  <- 0  
dersigma2.dersigma2.st2 <- 0


if(max(y2) > 170){

prec <- pmax(53, getPrec(mu2), getPrec(y2))
        
mu2 <- mpfr(mu2, prec)
y2  <- mpfr( y2, prec)        
        
}        
     
     
pdf2FUNCdgp0 <- function(y2, mu2) exp(-y2/mu2) - exp(-(y2+1)/mu2)  
pdf2        <- as.numeric( pdf2FUNCdgp0(y2, mu2) )      
     
     
derpdf2.dermu2FUNCdgp0 <- function(y2, mu2) (y2 * exp(-(y2/mu2)) - (1 + y2) * exp(-((1 + y2)/mu2)))/mu2^2 
derpdf2.dermu2       <- as.numeric( derpdf2.dermu2FUNCdgp0(y2, mu2) )
    
der2pdf2.dermu2FUNCdgp0 <- function(y2, mu2) ((y2^2 * exp(-(y2/mu2)) - (1 + y2)^2 * exp(-((1 + y2)/mu2)))/mu2 - 2 * (y2 * exp(-(y2/mu2)) - (1 + y2) * exp(-((1 + y2)/mu2))))/mu2^3  
der2pdf2.dermu2       <- as.numeric( der2pdf2.dermu2FUNCdgp0(y2, mu2) )
    
derpdf2.sigma2        <- 0
der2pdf2.dersigma22   <- 0
der2pdf2.mu2dersigma2 <- 0



if(naive == FALSE){   # needs y2m 
 
mu2 <- c(mu2) 

p2  <- rowSums( matrix(as.numeric(pdf2FUNCdgp0(y2m, mu2)),dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE )

derp2.dermu2           <- rowSums( matrix(as.numeric(derpdf2.dermu2FUNCdgp0(y2m, mu2)), dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE ) 
derp2.dersigma2        <- 0
der2p2.dermu22         <- rowSums( matrix(as.numeric(der2pdf2.dermu2FUNCdgp0(y2m, mu2)),dim(y2m)[1],dim(y2m)[2]), na.rm = TRUE ) 
der2p2.dersigma22      <- 0
der2p2.derdermu2sigma2 <- 0


                      
    
                   }

}





###
###




# 11 oct 2018, decided to use all numerical, balancing several things

if(margin2 == "NBI"){ # all Numerical - does not need y2m

#sigma <- sigma2 <- ifelse(sigma2 < 4.151334e-06, 4.151334e-06, sigma2) # related to gamma function

sigma <- sigma2 <- ifelse(sigma2 < 1e-04, 1e-04, sigma2) # related to gamma function
sigma2.st <- log(sigma2) 

mu2  <- exp(eta2)
mu2  <- ifelse(mu2 < 1e-04, 1e-04, mu2) # for numerical dervs
eta2 <- log(mu2) 


dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2) 

dersigma2.dersigma2.st  <- exp(sigma2.st)  
dersigma2.dersigma2.st2 <- exp(sigma2.st)  


pdf2 <- dNBI(y2, mu = mu2, sigma = sigma)  

derpdf2.dermu2F <- derpdf2.dermu2FUNC2p(function(mu2) dNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.dermu2  <- derpdf2.dermu2F$fi 
der2pdf2.dermu2 <- derpdf2.dermu2F$se  


derpdf2.sigma2F     <- derpdf2.sigma2FUNC2p(function(sigma) dNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.sigma2      <- derpdf2.sigma2F$fi      
der2pdf2.dersigma22 <- derpdf2.sigma2F$se    


der2pdf2.mu2dersigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) dNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)


if(naive == FALSE){   
 
p2  <- pNBI(y2, mu = mu2, sigma = sigma)  
 
derp2.dermu2F  <- derpdf2.dermu2FUNC2p(function(mu2) pNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)
derp2.dermu2   <- derp2.dermu2F$fi
der2p2.dermu22 <- derp2.dermu2F$se

derp2.dersigma2F <- derpdf2.sigma2FUNC2p(function(sigma) pNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derp2.dersigma2  <- derp2.dersigma2F$fi 
der2p2.dersigma22<- derp2.dersigma2F$se 

der2p2.derdermu2sigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) pNBI(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 

  
                   }

}





#######





if(margin2 == "NBII"){ # all Numerical - does not need y2m

sigma <- sigma2 <- ifelse(sigma2 < 1e-04, 1e-04, sigma2) # related to gamma function

sigma2.st <- log(sigma2) 

mu2  <- exp(eta2)
mu2  <- ifelse(mu2 < 1e-04, 1e-04, mu2) 
eta2 <- log(mu2) 

dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2) 

dersigma2.dersigma2.st  <- exp(sigma2.st)  
dersigma2.dersigma2.st2 <- exp(sigma2.st)  


pdf2 <- dNBII(y2, mu = mu2, sigma = sigma)  

derpdf2.dermu2F <- derpdf2.dermu2FUNC2p(function(mu2) dNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.dermu2  <- derpdf2.dermu2F$fi 
der2pdf2.dermu2 <- derpdf2.dermu2F$se  


derpdf2.sigma2F     <- derpdf2.sigma2FUNC2p(function(sigma) dNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.sigma2      <- derpdf2.sigma2F$fi      
der2pdf2.dersigma22 <- derpdf2.sigma2F$se    


der2pdf2.mu2dersigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) dNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)


if(naive == FALSE){   
 
p2  <- pNBII(y2, mu = mu2, sigma = sigma)  
 
derp2.dermu2F  <- derpdf2.dermu2FUNC2p(function(mu2) pNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)
derp2.dermu2   <- derp2.dermu2F$fi
der2p2.dermu22 <- derp2.dermu2F$se

derp2.dersigma2F <- derpdf2.sigma2FUNC2p(function(sigma) pNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derp2.dersigma2  <- derp2.dersigma2F$fi 
der2p2.dersigma22<- derp2.dersigma2F$se 

der2p2.derdermu2sigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) pNBII(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 

  
                   }

}





#############################

if(margin2 == "PIG"){ # K all numerical as well
                      # sigma <- ifelse(sigma>precision, sigma, precision)
                      # sigma <- ifelse(sigma<10^7, sigma, 10^7)
                      # tolerances for derivatives may be changed to get better
                      # performace, difficult to find a general rule here
    
sigma <- sigma2 <- ifelse(sigma2 < 1e-04, 1e-04, sigma2) 
sigma2.st <- log(sigma2) 
    

mu2  <- exp(eta2)
mu2  <- ifelse(mu2 < 1e-04, 1e-04, mu2) # safety check for num derivs
eta2 <- log(mu2) 

dermu2.dereta2 <- exp(eta2)
der2mu2.dereta2eta2 <- exp(eta2) 

dersigma2.dersigma2.st  <- exp(sigma2.st)  
dersigma2.dersigma2.st2 <- exp(sigma2.st)  


pdf2 <- dPIG(y2, mu = mu2, sigma = sigma)    

derpdf2.dermu2F <- derpdf2.dermu2FUNC2p(function(mu2) dPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.dermu2  <- derpdf2.dermu2F$fi 
der2pdf2.dermu2 <- derpdf2.dermu2F$se     
    
 
derpdf2.sigma2F     <- derpdf2.sigma2FUNC2p(function(sigma) dPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derpdf2.sigma2      <- derpdf2.sigma2F$fi      
der2pdf2.dersigma22 <- derpdf2.sigma2F$se 
   
der2pdf2.mu2dersigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) dPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)


if(naive == FALSE){   
 
p2  <- pPIG(y2, mu = mu2, sigma = sigma) 
 
derp2.dermu2F  <- derpdf2.dermu2FUNC2p(function(mu2) pPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma)
derp2.dermu2   <- derp2.dermu2F$fi
der2p2.dermu22 <- derp2.dermu2F$se
    
derp2.dersigma2F <- derpdf2.sigma2FUNC2p(function(sigma) pPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
derp2.dersigma2  <- derp2.dersigma2F$fi 
der2p2.dersigma22<- derp2.dersigma2F$se 
   
der2p2.derdermu2sigma2 <- der2pdf2.mu2dersigma2FUNC2p(function(mu2, sigma) pPIG(y2, mu = mu2, sigma = sigma), y2, mu2, sigma) 
  

                   }

}



if(margin2 %in% c("DGP","DGPII") ){




if(margin2 == "DGP"){
    
                   mu2  <- eta2 # exi
dermu2.dereta2          <- 1
der2mu2.dereta2eta2     <- 0 


}


if(margin2 == "DGPII"){

#                   mu2  <- eta2^2 # exi
#dermu2.dereta2          <- 2*eta2
#der2mu2.dereta2eta2     <- 2 

                   mu2  <- exp(eta2) # exi
dermu2.dereta2          <- exp(eta2)
der2mu2.dereta2eta2     <- exp(eta2)

}


dersigma2.dersigma2.st  <- exp(sigma2.st)  # sigma
dersigma2.dersigma2.st2 <- exp(sigma2.st)  


indx1 <- as.numeric( ((1 + mu2*y2/sigma)     > 0) == FALSE ) 
indx2 <- as.numeric( ((1 + mu2*(y2+1)/sigma) > 0) == FALSE ) # this is not needed
indx  <- rowSums(cbind(indx1, indx2))


pdf2FUNC <- function(y2, mu2, sigma) suppressWarnings(   (1 + mu2*y2/sigma)^(-1/mu2) - (1 + mu2*(1+y2)/sigma)^(-1/mu2)    )  


derpdf2.dermu2FUNC        <- function(y2, mu2, sigma) suppressWarnings(  (((1 + y2)/(1 + mu2 * (1 + y2)/sigma)^(1 + 1/mu2) - y2/(1 + mu2 * 
    y2/sigma)^(1 + 1/mu2))/sigma + (log1p(mu2 * y2/sigma)/(1 + 
    mu2 * y2/sigma)^(1/mu2) - log1p(mu2 * (1 + y2)/sigma)/(1 + 
    mu2 * (1 + y2)/sigma)^(1/mu2))/mu2)/mu2   )


derpdf2.sigma2FUNC        <- function(y2, mu2, sigma)  suppressWarnings(  -(((1 + y2)/(1 + mu2 * (1 + y2)/sigma)^(1 + 1/mu2) - y2/(1 + 
    mu2 * y2/sigma)^(1 + 1/mu2))/sigma^2)  )

       
der2pdf2.dermu2FUNC       <- function(y2, mu2, sigma) suppressWarnings( (((log1p(mu2 * y2/sigma) * (log1p(mu2 * y2/sigma)/(mu2 * (1 + 
    mu2 * y2/sigma)^(1/mu2)) - y2/(sigma * (1 + mu2 * y2/sigma)^(1 + 
    1/mu2))) - log1p(mu2 * (1 + y2)/sigma) * (log1p(mu2 * (1 + 
    y2)/sigma)/(mu2 * (1 + mu2 * (1 + y2)/sigma)^(1/mu2)) - (1 + 
    y2)/(sigma * (1 + mu2 * (1 + y2)/sigma)^(1 + 1/mu2))))/mu2 + 
    (y2/(sigma * (1 + mu2 * y2/sigma)) - 2 * (log1p(mu2 * y2/sigma)/mu2))/(1 + 
        mu2 * y2/sigma)^(1/mu2) - ((1 + y2)/(sigma * (1 + mu2 * 
    (1 + y2)/sigma)) - 2 * (log1p(mu2 * (1 + y2)/sigma)/mu2))/(1 + 
    mu2 * (1 + y2)/sigma)^(1/mu2))/mu2 + (y2 * ((1/(1 + mu2 * 
    y2/sigma)^(1 + 1/mu2) - log1p(mu2 * y2/sigma)/(mu2 * (1 + 
    mu2 * y2/sigma)^(1 + 1/mu2)))/mu2 + y2 * (1 + 1/mu2)/(sigma * 
    (1 + mu2 * y2/sigma)^(1/mu2 + 2))) - ((1 + 1/mu2) * (1 + 
    y2)/(sigma * (1 + mu2 * (1 + y2)/sigma)^(1/mu2 + 2)) + (1/(1 + 
    mu2 * (1 + y2)/sigma)^(1 + 1/mu2) - log1p(mu2 * (1 + y2)/sigma)/(mu2 * 
    (1 + mu2 * (1 + y2)/sigma)^(1 + 1/mu2)))/mu2) * (1 + y2))/sigma)/mu2  )

    
der2pdf2.dersigma22FUNC   <- function(y2, mu2, sigma) suppressWarnings(  (y2 * (mu2 * y2 * (1 + 1/mu2)/(sigma * (1 + mu2 * y2/sigma)^(1/mu2 + 
    2)) - 2/(1 + mu2 * y2/sigma)^(1 + 1/mu2)) - (1 + y2) * (mu2 * 
    (1 + 1/mu2) * (1 + y2)/(sigma * (1 + mu2 * (1 + y2)/sigma)^(1/mu2 + 
    2)) - 2/(1 + mu2 * (1 + y2)/sigma)^(1 + 1/mu2)))/sigma^3  )

    
der2pdf2.mu2dersigma2FUNC <- function(y2, mu2, sigma) suppressWarnings(  -(((1 + y2) * (log1p(mu2 * (1 + y2)/sigma)/(mu2^2 * (1 + mu2 * 
    (1 + y2)/sigma)^(1 + 1/mu2)) - (1 + 1/mu2) * (1 + y2)/(sigma * 
    (1 + mu2 * (1 + y2)/sigma)^(1/mu2 + 2))) - y2 * (log1p(mu2 * 
    y2/sigma)/(mu2^2 * (1 + mu2 * y2/sigma)^(1 + 1/mu2)) - y2 * 
    (1 + 1/mu2)/(sigma * (1 + mu2 * y2/sigma)^(1/mu2 + 2))))/sigma^2)    )




pdf2                  <- as.numeric( pdf2FUNC(y2, mu2, sigma) )  
derpdf2.dermu2        <- derpdf2.dermu2FUNC(y2, mu2, sigma) 
derpdf2.sigma2        <- derpdf2.sigma2FUNC(y2, mu2, sigma) 
der2pdf2.dermu2       <- der2pdf2.dermu2FUNC(y2, mu2, sigma) 
der2pdf2.dersigma22   <- der2pdf2.dersigma22FUNC(y2, mu2, sigma) 
der2pdf2.mu2dersigma2 <- der2pdf2.mu2dersigma2FUNC(y2, mu2, sigma)



pdf2                  <- ifelse( indx == 0, pdf2, 1) # 'cause in output log(1) = 0 hence it will not add anything to the lik
derpdf2.dermu2        <- ifelse( indx == 0, derpdf2.dermu2, 0) 
derpdf2.sigma2        <- ifelse( indx == 0, derpdf2.sigma2, 0) 
der2pdf2.dermu2       <- ifelse( indx == 0, der2pdf2.dermu2, 0) 
der2pdf2.dersigma22   <- ifelse( indx == 0, der2pdf2.dersigma22, 0) 
der2pdf2.mu2dersigma2 <- ifelse( indx == 0, der2pdf2.mu2dersigma2, 0) 








if(naive == FALSE){   # needs y2m
 
ly2 <- length(y2)
if(length(sigma) == 1) sigma <- c(rep(sigma, ly2))

mu2    <- c(mu2)
sigma <- c(sigma)

derp2.dermu2           <- rowSums( derpdf2.dermu2FUNC(        y2m, mu2, sigma ) , na.rm = TRUE )
derp2.dersigma2        <- rowSums( derpdf2.sigma2FUNC(        y2m, mu2, sigma ) , na.rm = TRUE )
der2p2.dermu22         <- rowSums( der2pdf2.dermu2FUNC(       y2m, mu2, sigma ) , na.rm = TRUE )
der2p2.dersigma22      <- rowSums( der2pdf2.dersigma22FUNC(   y2m, mu2, sigma ) , na.rm = TRUE )
der2p2.derdermu2sigma2 <- rowSums( der2pdf2.mu2dersigma2FUNC( y2m, mu2, sigma ) , na.rm = TRUE )


                   }

}






##########################################################

# GBS: The derivatives that I extract here are not all the way up to eta2!
# This part connects the derivatives of pdf2 w.r.t. mu2 to the derivatives of mu2 w.r.t. eta2
if( MBS ){
  
  if(margin2 %in% c(cont2par,cont3par)){ 
    
    # This object is already a collection of vectors of dimensions "length(beta)"! ready to be used as colSums!!!
    derpdf2.dereta2              <- derpdf2.derbeta2#derpdf2.dermu2  *dermu2.dereta2      
    
    # This object is already a list of matrices : der2_pdf2 ____ derbeta betaT
    der2pdf2.dereta2             <- der2pdf2.dermu2  #* dermu2.dereta2^2 + derpdf2.dermu2*der2mu2.dereta2eta2        
    
    
    der2pdf2.dereta2dersigma2    <- der2pdf2.mu2dersigma2* dermu2.dereta2
    der2pdf2.dereta2dersigma2.st <- der2pdf2.dereta2dersigma2 *  dersigma2.dersigma2.st
    
    
    derpdf2.dersigma2.st         <- derpdf2.sigma2 * dersigma2.dersigma2.st   
    der2pdf2.dersigma2.st2       <- der2pdf2.dersigma22 * dersigma2.dersigma2.st^2 + derpdf2.sigma2  * dersigma2.dersigma2.st2     
    
    
    
    if(naive == FALSE){  
      
      
      # Collection of row-vectors
      derp2.dereta2                <- derp2.dermu2# derp2.dereta2 #derp2.dermu2  *dermu2.dereta2
      
      # List of matrices
      der2p2.dereta2eta2           <- der2p2.dermu22 #*dermu2.dereta2^2+derp2.dermu2*der2mu2.dereta2eta2      
      
      
      der2p2.dereta2dersigma2      <- der2p2.derdermu2sigma2* dermu2.dereta2    
      der2p2.dereta2dersigma2.st   <- der2p2.dereta2dersigma2 *  dersigma2.dersigma2.st  
      
      derp2.dersigma.st            <- derp2.dersigma2 *  dersigma2.dersigma2.st 
      der2p2.dersigma2.st2         <- der2p2.dersigma22 * dersigma2.dersigma2.st^2 + derp2.dersigma2 * dersigma2.dersigma2.st2
      
      
      
      
      
    }
    
    
    
    
  }
  
  
}else{


if(margin2 %in% c(cont2par,cont3par)){ 

derpdf2.dereta2              <- derpdf2.dermu2*dermu2.dereta2       
der2pdf2.dereta2             <- der2pdf2.dermu2* dermu2.dereta2^2 + derpdf2.dermu2*der2mu2.dereta2eta2        


der2pdf2.dereta2dersigma2    <- der2pdf2.mu2dersigma2* dermu2.dereta2
der2pdf2.dereta2dersigma2.st <- der2pdf2.dereta2dersigma2 *  dersigma2.dersigma2.st

  
derpdf2.dersigma2.st         <- derpdf2.sigma2 * dersigma2.dersigma2.st   
der2pdf2.dersigma2.st2       <- der2pdf2.dersigma22 * dersigma2.dersigma2.st^2 + derpdf2.sigma2  * dersigma2.dersigma2.st2     

                  

if(naive == FALSE){  



derp2.dereta2                <- derp2.dermu2*dermu2.dereta2
der2p2.dereta2eta2           <- der2p2.dermu22*dermu2.dereta2^2+derp2.dermu2*der2mu2.dereta2eta2      


der2p2.dereta2dersigma2      <- der2p2.derdermu2sigma2* dermu2.dereta2    
der2p2.dereta2dersigma2.st   <- der2p2.dereta2dersigma2 *  dersigma2.dersigma2.st  

derp2.dersigma.st            <- derp2.dersigma2 *  dersigma2.dersigma2.st 
der2p2.dersigma2.st2         <- der2p2.dersigma22 * dersigma2.dersigma2.st^2 + derp2.dersigma2 * dersigma2.dersigma2.st2





                 }
                 
                 
                 

}

}  
  
###############



pdf2 <- ifelse(pdf2 < min.dn, min.dn, pdf2)
p2   <- mm(p2, min.pr = min.pr, max.pr = max.pr) 


# GBS: ADD ONE NICE CONTROL HERE FOR MBS before the result is 
# generated

if( MBS ){
  
  
  # Note: derpdf2.dereta2 is INCOMPLETE, it does not include the derivative of pdf2 all the way up to eta!
  #       Same thing applies to the Hessian terms and to the P2 terms!
  # Please note that the derivatives of pdf2 and p2 w.r.t. mu2 are actually not these quantities!
  # they will be further modified in the next function!!!
  
  # Added: mu2 (after going through ifef())
  
  list(
    #
    # Here only pdf2 and p2 need the ifef(x) check. The remaining quantities are already vectors / matrices, so the check is OMMITTED!
    pdf2                         = ifef(pdf2),
    p2                           = ifef(p2), 
    derpdf2.dereta2              = derpdf2.dereta2, #  ifef(derpdf2.dereta2),  # this is a vector! 
    #
    # THOSE TWO BELOW ARE NOT NEEDED
    derpdf2.dersigma2.st         = ifef(derpdf2.dersigma2.st), 
    derp2.dersigma.st            = ifef(derp2.dersigma.st),
    #
    #
    # These three are needed
    derp2.dereta2                = derp2.dereta2, #   ifef(derp2.dereta2), # this is a vector 
    der2p2.dereta2eta2           = der2p2.dereta2eta2,#  ifef(der2p2.dereta2eta2),  # this is a vector!
    der2pdf2.dereta2             = der2pdf2.dereta2,#  ifef(der2pdf2.dereta2), # this is a vector!
    #
    #
    # Everything below is not needed
    der2p2.dersigma2.st2         = ifef(der2p2.dersigma2.st2), 
    der2pdf2.dersigma2.st2       = ifef(der2pdf2.dersigma2.st2),
    der2p2.dereta2dersigma2.st   = ifef(der2p2.dereta2dersigma2.st),  
    der2pdf2.dereta2dersigma2.st = ifef(der2pdf2.dereta2dersigma2.st),
    der2pdf2.dereta2dernu.st     = ifef(der2pdf2.dereta2dernu.st),   
    der2pdf2.sigma2.st2dernu.st  = ifef(der2pdf2.sigma2.st2dernu.st),
    derpdf2.dernu.st             = ifef(derpdf2.dernu.st),           
    der2pdf2.dernu.st2           = ifef(der2pdf2.dernu.st2),         
    derp2.nu.st                  = ifef(derp2.nu.st),                
    der2p2.dernu.st2             = ifef(der2p2.dernu.st2),           
    der2p2.dereta2dernu.st       = ifef(der2p2.dereta2dernu.st),     
    der2p2.dersigma2.stdernu.st  = ifef(der2p2.dersigma2.stdernu.st), 
    #
    #
    # Just mu2 is needed
    mu2                          = mu2,  # this is a scalar and ifef(x) was already carried out before!  I removed ifef from this step!
    #
    #
    #
    indx = indx == 0         )     
  
  
  
}else{

list(
pdf2                         = ifef(pdf2),
p2                           = ifef(p2), 
derpdf2.dereta2              = ifef(derpdf2.dereta2), 
derpdf2.dersigma2.st         = ifef(derpdf2.dersigma2.st), 
derp2.dersigma.st            = ifef(derp2.dersigma.st),
derp2.dereta2                = ifef(derp2.dereta2),
der2p2.dereta2eta2           = ifef(der2p2.dereta2eta2), 
der2pdf2.dereta2             = ifef(der2pdf2.dereta2),
der2p2.dersigma2.st2         = ifef(der2p2.dersigma2.st2), 
der2pdf2.dersigma2.st2       = ifef(der2pdf2.dersigma2.st2),
der2p2.dereta2dersigma2.st   = ifef(der2p2.dereta2dersigma2.st),  
der2pdf2.dereta2dersigma2.st = ifef(der2pdf2.dereta2dersigma2.st),
der2pdf2.dereta2dernu.st     = ifef(der2pdf2.dereta2dernu.st),   
der2pdf2.sigma2.st2dernu.st  = ifef(der2pdf2.sigma2.st2dernu.st),
derpdf2.dernu.st             = ifef(derpdf2.dernu.st),           
der2pdf2.dernu.st2           = ifef(der2pdf2.dernu.st2),         
derp2.nu.st                  = ifef(derp2.nu.st),                
der2p2.dernu.st2             = ifef(der2p2.dernu.st2),           
der2p2.dereta2dernu.st       = ifef(der2p2.dereta2dernu.st),     
der2p2.dersigma2.stdernu.st  = ifef(der2p2.dersigma2.stdernu.st), 
                        indx = indx == 0         )     


}
  
}




    